DumVar <-
function(x)
{
    xmx <- max(x)
    ndu <- xmx-1
    dum <- matrix(0,nrow=length(x),ncol=ndu)

    for (j in 2:xmx)
    {
        ok <- which(x==j)
        dum[ok,(j-1)] <- 1
    }
    dum
}
