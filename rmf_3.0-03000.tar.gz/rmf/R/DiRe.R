DiRe <-
function(x1,x2,y1,y2)
{
    lines(c(x1,x2),c(y1,y1))
    lines(c(x2,x2),c(y1,y2))
    lines(c(x2,x1),c(y2,y2))
    lines(c(x1,x1),c(y2,y1))
}
