erre <-
function(x,y) cor(x, y, use = "complete.obs", method = "pearson")
