torta <-
function(x,nome=NULL,...)
{
           if (is.null(nome)) nome <- substitute(x)
           nome <- as.character(nome)
           if (length(nome)>1) nome <- nome[length(nome)]
           dd <- table(x)
           d <- dd[dd>0]
           tit <- paste("Diagramma a torta:",nome)
           pie(d,main=tit,...)
}
