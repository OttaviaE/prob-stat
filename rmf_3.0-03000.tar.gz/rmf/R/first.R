first <-
function(brk,x,type="GE")
{
     nbrk <- length(brk)
     pos <- rep(NA,nbrk)
     for (i in 1:nbrk){
          ctf <- brk[i]
          switch(type,
             EQ = a <- which(x==ctf),
             NE = a <- which(x!=ctf),
             GT = a <- which(x>ctf) ,
             GE = a <- which(x>=ctf),
             LT = a <- which(x<ctf) ,
             LE = a <- which(x<=ctf))
          if (length(a)>0) pos[i] <- a[1]
     }
     pos
}
