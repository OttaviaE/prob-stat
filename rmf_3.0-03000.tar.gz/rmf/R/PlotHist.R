PlotHist <-
function(inp,xlbl,main)
{
    minx <- min(inp$breaks); maxx <- max(inp$breaks)
    miny <- min(inp$intensities); maxy <- max(inp$intensities)
    plot(c(0,0),c(0,0),xlim=c(minx,maxx),ylim=c(miny,maxy),type="n",
         xlab=xlbl,ylab="Frequenze relative",axes=FALSE,main=main)
    axis(2)
    box()
    axis(1,inp$breaks)
    nbr <- length(inp$breaks)-1
    for (i in 1:nbr) {
        x1 <- inp$breaks[i]; x2 <- inp$breaks[i+1]
        y2 <- inp$intensities[i]
        DiRe(x1,x2,0,y2)
    }
}
