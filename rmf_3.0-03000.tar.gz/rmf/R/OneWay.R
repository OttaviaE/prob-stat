OneWay <-
function(m,s,n)
{
    lm <- length(m)
    ls <- length(s)
    ln <- length(n)
    if (lm != ls) stop("Numero di elementi non coincidente.")
    if (lm != ln) stop("Numero di elementi non coincidente.")
    if (ls != ln) stop("Numero di elementi non coincidente.")
    if (sum(s>0) != ls) stop("Deviazioni standard nulle o negative.")
    if (sum(n>0) != ln) stop("Numerosita' nulle o negative.")

    mgen <- sum(m*n)/sum(n)
    dev <- s^2*(n-1);      deve <- sum(dev)
    dev <- (m - mgen)^2*n; devf <- sum(dev)
    devt <- devf+deve
    glt <- sum(n)-1; glf <- lm-1; gle <- glt-glf
    varf <- devf/glf; vare <- deve/gle
    testF <- varf/vare
    pv <- pf(testF,glf,gle,lower.tail=FALSE)

    ssq  <- c(devf,deve)
    glib <- c(glf,gle)
    msq  <- c(varf,vare)
    Fval <- c(testF,NA)
    pval <- c(pv,NA)

# trucco inizio
    y <- rnorm(n=10*lm); gruppo <- factor(rep(c(1:lm),each=10),ordered=FALSE)
    Aov <- aov(y ~ gruppo); out <- summary(Aov)
# trucco fine

    out[[1]][1] <- glib
    out[[1]][2] <- ssq
    out[[1]][3] <- msq
    out[[1]][4] <- Fval
    out[[1]][5] <- pval
    return(out)
}
