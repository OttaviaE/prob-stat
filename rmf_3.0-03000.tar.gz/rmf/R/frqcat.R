frqcat <-
function(x)
{
   if (!is.data.frame(x)) x <- as.data.frame(x)
   nmx <- names(x)
   nvar <- dim(x)[2]
   tmp  <- summary(x)
   for (i in 1:nvar) {
       a <- tmp[1,i]
       b <- leftdol(a,4)
       if (b != "Min.") {
          cat("Variabile numero",i,"-",nmx[i],"\n")
          for (j in 1:nrow(tmp)) if (!is.na(tmp[j,i])) print(tmp[j,i])
             nmsng <- sum(is.na(x[,i]))
             cat("Osservazioni mancanti:",nmsng,"\n\n")
       }
   }
}
