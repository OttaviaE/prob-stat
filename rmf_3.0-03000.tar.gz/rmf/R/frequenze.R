frequenze <-
function(x,cumul=FALSE,sort=FALSE,mult=100)
{
     if (!is.null(ncol(x))) stop("frequenze lavora con una sola variabile.")
     frq(x,cumul,sort,mult)
}
