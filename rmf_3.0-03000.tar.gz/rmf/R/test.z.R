test.z <-
function(media=NA,sigma=0,n=0,mu0=NA,dati=NULL,conf=0.95) 
{
    ds <- sigma
    x <- dati
    if (!is.null(x)) {
       ok <- which(!is.na(x))
       tmp <- x[ok]
       m1 <- mean(tmp)
       n1 <- length(tmp)
    }
    if (is.null(x)) {
        m1 <- media
        n1 <- n
    }

    if ((ds<=0) | (n1<=0)) stop("Parametro/i non valido/i.")

    umalpha <- conf
    if ((umalpha <0.4) | (umalpha>=1)) umalpha <- 0.95

    ds1 <- ds
    v1 <- ds1^2
    se <- sqrt(v1/n1)

    pr <- umalpha+(1-umalpha)/2
    zcr <- qnorm(pr)
    ei <- m1-zcr*se
    es <- m1+zcr*se
    cat("media =",m1," d.s. =",sqrt(v1)," es =",se," n =",n1,"\n")
    cat("Intervallo di confidenza al ",umalpha*100,
        "% per la media: da ",ei," a ",es,"\n")

    if (!is.na(mu0)) {
       z <- (m1-mu0)/se
       pvalz <- pnorm(abs(z))
       pvalz <- (1-pvalz)*2
       cat("\nIpotesi nulla: mu =",mu0,"media =",m1," ES =",se," n =",n1,"\n")
       cat("Regione di non rifiuto per l'ipotesi nulla ",
           "(alpha =",(1-umalpha),"): da ",mu0-zcr*se,
           " a ",mu0+zcr*se,"\n")
       cat("Test z:",z," p-value =",pvalz,"\n")
    }
}
