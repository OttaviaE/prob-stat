summary.tcc <-
function(obj, ...)
{
    obj <- obj[[1]]
    nc <- nrow(obj)
    p <- obj[,6]
    pb <- p*nc
    pb[pb>1] <- 1
    obj[,6] <- pb
    colnames(obj)[6] <- "p Bonf."
    return(obj[,1:6])
}
