cumulata <-
function(x,retroc=FALSE,nome=NULL,...)
{
               if (is.null(nome)) nome <- substitute(x)
               nome <- as.character(nome)
               if (length(nome)>1) nome <- nome[length(nome)]
               pippo <- table(x)
               n <- sum(pippo)
               pippo <- cumsum(pippo)/n*100
               if (retroc) pippo <- 100-pippo
               np <- length(pippo)-1
               xx <- names(pippo)
               plot(names(pippo),pippo,type="n",xlab=nome,ylab="percentuale",...)
               for (i in 1:np) {
                   x <- c(xx[i],xx[i+1])
                   y <- c(pippo[i],pippo[i])
                   lines(x,y)
                   x <- c(xx[i+1],xx[i+1])
                   y <- c(pippo[i],pippo[i+1])
                   lines(x,y)
               }
}
