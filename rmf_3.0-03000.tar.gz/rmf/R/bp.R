bp <-
function(x,nome=NULL,...)
{
        if (is.null(nome)) nome <- substitute(x)
        nome <- as.character(nome)
        if (length(nome)>1) nome <- nome[length(nome)]
        boxplot(x,ylab=nome,...)
        rug(x,side=2)
}
