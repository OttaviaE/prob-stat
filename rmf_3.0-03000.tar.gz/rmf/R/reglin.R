reglin <-
function(x,y,grafico=FALSE)
{
   fit <- lm(y~x)
   erre <- cor(x,y,use="compl",method="pearson")
   n <- fit$df+2
   varr <- (1-erre^2)/(n-2)
   ttest <- abs(erre)/sqrt(varr)
   pval <- 2 * pt(ttest,(n-2),lower.tail=FALSE)
   yvar <- as.character(substitute(y))
   xvar <- as.character(substitute(x))
   cat("Variabile dipendente  :",yvar,"\n")
   cat("Variabile indipendente:",xvar,"\n")
   cat("Intercetta:",fit$coef[1],"\n")
   cat("Pendenza  :",fit$coef[2],"\n")
   cat("% variabilita' spiegata:",(erre^2)*100,"\n")
   cat("Numero di coppie di osservazioni:",n,"\n")
   cat("Test t per l'assenza di regressione lineare:",ttest,"\n")
   cat("p-value =",pval,"\n")
   if (grafico) {
      plot(x,y,xlab=substitute(x),ylab=substitute(y))
      abline(fit)
   }
}
