PrintHist <-
function(pippo,destra)
{
          if (destra) cat("L'intervallo e' chiuso a destra.\n") else
                      cat("L'intervallo e' aperto a destra.\n")
          estr <- pippo$breaks
          f <- pippo$counts
          t <- sum(f)
          n <- length(f)
          pcg <- pcg <- (f/t)*100
          F <- cumsum(f)
          PCG <- (F/t)*100
          f <- append(f,t)
          pcg <- append(pcg,sum(pcg))
          F <- append(F,NA)
          PCG <- append(PCG,NA)
          nf1 <- estr[1:n]
          nf2 <- estr[2:(n+1)]
          nf1 <- append(nf1," ")
          nf2 <- append(nf2," ")
          FX <- cbind(format(nf1),format(nf2),format(f),format(pcg),format(F),format(PCG))
          nch <- nchar(FX[2,])+2
          r <- ""
          nii <- 6
          for (i in 1:nii) {
              r <- paste(r,"+",sep="")
              for (j in 1:nch[i]) r <- paste(r,"-",sep="")
          }
          riga <- paste(r,"+",sep="")
          abcd <- c("da","a ","n ","f ","N ","F ")
          r <- ""
          for (i in 1:nii) {
              r <- paste(r," ",sep="")
              for (j in 1:(nch[i]-2)) r <- paste(r," ",sep="")
              r <- paste(r,abcd[i],sep="")
          }
               intesta <- r
               cat(intesta,"\n")
               cat(riga,"\n")
               for (i in 1:n) {
                   r <- paste("|",FX[i,1],"|",FX[i,2],"|",FX[i,3],"|",FX[i,4],"|",FX[i,5],"|",FX[i,6],"|")
                   cat(r,"\n")
               }
               cat(riga,"\n")
}
