simicp <-
function(nobs=10,p=0.5,conf=0.95,nsim=20,grafico=NA)
{
     if (is.na(grafico) & (nsim<=100)) grafico=TRUE
     if (is.na(grafico) & (nsim> 100)) grafico=FALSE
     umalpha <- conf
     if (umalpha > 1) umalpha <- umalpha/100
     alpha <- umalpha
     a2 <- alpha+(1-alpha)/2
     za2 <- qnorm(a2,0,1)
     x <- rbinom(nsim,nobs,p)
     ph <- x/nobs
     varph <- ph*(1-ph)/nobs
     seph <- sqrt(varph)
     cil <- ph - za2*seph
     cih <- ph + za2*seph

     a <- (cil <= p)*(p <= cih)
     cat ("Simulazione di ",nsim," intervalli di confidenza al ",(conf*100),"%\n",sep="")
     cat ("su campioni di dimensione ",nobs," estratti da una Bernoulli\n",sep="")
     cat ("con parametro p uguale a ",p,"\n",sep="")

     cat ("Numero di intervalli che cadono a sinistra di ",p," :",(sum(cih<p)),"\n")
     cat ("Numero di intervalli che cadono a destra   di ",p," :",(sum(p<cil)),"\n")
     cat ("Numero di intervalli che contengono il valore ",p," :",(sum(a)),"\n")
     cat ("Percentuale di intervalli che contengono      ",p," :",(sum(a)/nsim*100),"\n")

     tmp <- binconf(x, rep(nobs,nsim), (1-umalpha))
     b <- (tmp[,2] <= p)*(p <= tmp[,3])
     cat ("Intervallo di confidenza esatto... (verificare Hmisc)\n")
     cat ("Numero di intervalli che cadono a sinistra di ",p," :",(sum(tmp[,3]<p)),"\n")
     cat ("Numero di intervalli che cadono a destra   di ",p," :",(sum(p<tmp[,2])),"\n")
     cat ("Numero di intervalli che contengono il valore ",p," :",(sum(b)),"\n")
     cat ("Percentuale di intervalli che contengono      ",p," :",(sum(b)/nsim*100),"\n")

     nrig <- c(1:nsim)
     o <- order(cih)
     x <- x[o]
     ph <- ph[o]
     seph <- seph[o]
     cil <- cil[o]
     cih <- cih[o]
     a <- a[o]
     nrig <- nrig[o]

     out <- cbind(ph,seph,cil,cih,a,nrig)
     colnames(out) <- c("p stim.","ES","estr. inf.","estr. sup.","flag","camp. n.")
     if (grafico) {
        tit <- paste(nsim," intervalli di confidenza al ",(umalpha*100),sep="")
        tit <- paste(tit,"%\nper la media di una Bernoulli",sep="")
        plotic(out,p,umalpha,tit)
     }
     out
}
