read.xls <-
function(NomeFile,NomeFoglio,sepdec=".",verbose=TRUE)
{
    con <- odbcConnectExcel(NomeFile)
    df <- sqlFetch(con,NomeFoglio,dec=sepdec)
    odbcCloseAll()
    if (verbose) str(df)
    df
}
