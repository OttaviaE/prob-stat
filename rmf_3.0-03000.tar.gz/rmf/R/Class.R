Class <-
function(x,verbose=FALSE)
{
      x <- as.data.frame(x)
      nc <- ncol(x)
      cls <- rep("Oth",nc)
      for (i in 1:nc) {
          y <- x[,i]
          tmp <- class(y); if (length(tmp)>1) tmp <- tmp[1]
          if (tmp=="integer")        cls[i] <- "N"
          if (tmp=="numeric")        cls[i] <- "N"
          if (tmp=="factor")         cls[i] <- "F"
          if (tmp=="ordered factor") cls[i] <- "OF"
          if (tmp=="ordered")        cls[i] <- "OF"
          if (tmp=="logical")        cls[i] <- "L"
          if (tmp=="character")      cls[i] <- "Ch"
          if (tmp=="Date")           cls[i] <- "D"
          if (tmp=="complex")        cls[i] <- "Co"
          if (verbose) cat(i,class(y),"\n")
      }
      cls
}
