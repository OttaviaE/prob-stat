FillNorm <-
function(xda,xa,mu,sigma,density,angle,color)
{
     v <- seq(xda,xa,length=100)
     x <- c(v[1],v,v[100],v[1])
     y <- c(0,dnorm(v,mean=mu,sd=sigma),0,0)
     if (is.na(color)) polygon(x,y,density=density,angle=angle)
        else polygon(x,y,col=color)
}
