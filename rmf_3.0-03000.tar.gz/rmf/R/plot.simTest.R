plot.simTest <-
function(obj, y, angle=45, color="red",...)
{
     alpha <- obj$alpha
     mu0 <- obj$mu0
     mu1 <- obj$mu1
     zcrit <- obj$zcrit
     sem <- obj$sem
     za2 <- obj$za2
     x <- obj$xx
     nrep <- obj$nrep
     a <- obj$a

     z <- x[,1]
     sigma <- x[1,2]

     if (!is.null(mu1)) {
        Normale(mu1,sigma,...)
        Normale(mu0,sigma,lty=3,add=TRUE)
     }
     if (is.null(mu1)) Normale(mu0,sigma,add=FALSE,...)

     xda <- mu0 - 5*sigma
     xa  <- mu0 - zcrit*sigma
     FillNorm(xda,xa,mu0,sigma,density,angle,color=color)

     xa  <- mu0 + 5*sigma
     xda <- mu0 + zcrit*sigma
     FillNorm(xda,xa,mu0,sigma,density,angle,color=color)

     rug(z)
}
