rightdol <-
function(strdol,k)
{
   l <- nchar(strdol)
   bdol <- substr(strdol,(l-k+1),l)
   bdol
}
