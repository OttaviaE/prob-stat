fps <-
function(x)
{
     x <- as.data.frame(x)
     idvar <- c(1:(dim(x)[2]))
     cls <- Class(x); ok <- which(cls=="N")
     x <- x[,ok]
     if (is.null(dim(x))) x <- as.data.frame(x)
     idvar <- idvar[ok]
     xxx <- apply(x,2,quantile,probs = seq(0, 1, 0.25), na.rm = TRUE,
            names = TRUE, type = 1)
     msn <- apply(x,2,nomis)
     nob <- nrow(x) - msn
     out <- cbind(idvar,t(xxx),nob,msn)
     colnames(out) <- c("nv","min","I quart","mediana","III quart","max",
        "nov","msng")
     out
}
