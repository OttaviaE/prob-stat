wrtTab <-
function(tbl)
{
     nrig <- dim(tbl)[1]
     nCol <- dim(tbl)[2]
     tgen <- sum(tbl)
     trig <- margin.table(tbl,1)
     tcol <- margin.table(tbl,2)
     pcr <- prop.table(tbl,1)*100
     pcc <- prop.table(tbl,2)*100
     nomivar <- names(dimnames(tbl))
     rowmod  <- dimnames(tbl)[[1]]
     colmod  <- dimnames(tbl)[[2]]
     maxl <- max(nchar(rowmod))
     if (maxl<9) maxl <- 9
     blk <- ""
     for (i in 1:maxl) blk <- paste(blk," ",sep="")
     for (ir in 1:nrig) {
         a <- paste(blk,rowmod[ir],sep="")
         rowmod[ir] <- rightdol(a,maxl)
     }
     for (ic in 1:nCol) {
         a <- paste("          ",colmod[ic],sep="")
         l <- nchar(a)
         a <- substr(a,(l-5+1),l)
         colmod[ic] <- a
     }
     a2 <- paste(blk,"FR.A. I"); a2 <- rightdol(a2,maxl+2)
     a3 <- paste(blk,"%RIGA I"); a3 <- rightdol(a3,maxl+2)
     a4 <- paste(blk,"%COL. I"); a4 <- rightdol(a4,maxl+2)
     a5 <- paste(blk,"     -+"); a5 <- rightdol(a5,maxl+2)
     a5b<- paste(blk,"      I"); a5b <- rightdol(a5b,maxl+2)
     a8 <- paste(blk,"TOTALE DI"); a8 <- rightdol(a8,maxl)
     a9 <- paste(blk,"  COLONNA"); a9 <- rightdol(a9,maxl)
     r1 <- paste(blk,"------+"); r1 <- rightdol(r1,maxl+2)
     for (ic in 1:nCol) r1 <- paste(r1,"------+",sep="")
     for (ic in 1:nCol) a2 <- paste(a2,"       ",sep="")
     for (ic in 1:nCol) a3 <- paste(a3,"       ",sep="")
     for (ic in 1:nCol) a4 <- paste(a4,colmod[ic]," I",sep="")
     a2 <- paste(a2," TOTALE")
     a3 <- paste(a3,"DI RIGA")
     cat(a2,"\n");cat(a3,"\n");cat(a4,"\n");cat(r1,"\n")
     for (ir in 1:nrig){
          r1 <- ""; r2<- ""; r3 <- "";r4 <- ""
         for (ic in 1:nCol){
              r1 <- paste(r1,sprintf("%5.0i", tbl[ir,ic])," I",sep="")
              r2 <- paste(r2,sprintf("%5.1f",pcr[ir,ic])," I",sep="")
              r3 <- paste(r3,sprintf("%5.1f",pcc[ir,ic])," I",sep="")
              r4 <- paste(r4,"------+",sep="")
         }
         r1 <- paste(r1,sprintf("%8.0i",trig[ir])         ,sep="")
         r1 <- paste(a5b,r1,sep="")
         r2 <- paste(r2,sprintf("%8.1f",trig[ir]/tgen*100),sep="")
         r2 <- paste(rowmod[ir]," I",r2,sep="")
         r3 <- paste(a5b,r3,sep="")
         r4 <- paste(a5,r4,sep="")
         cat(r1,"\n");cat(r2,"\n");cat(r3,"\n");cat(r4,"\n")
     }
     r1 <- ""; r2<- ""
     for (ic in 1:nCol){
          r1 <- paste(r1,sprintf("%5.0i",tcol[ic])         ,"  ",sep="")
          r2 <- paste(r2,sprintf("%5.1f",tcol[ic]/tgen*100),"  ",sep="")
     }
     r1 <- paste(a8,"  ",r1,sprintf("%8.0i",tgen),sep="")
     r2 <- paste(a9,"  ",r2,sep="")
     cat(r1,"\n");cat(r2,"\n")
}
