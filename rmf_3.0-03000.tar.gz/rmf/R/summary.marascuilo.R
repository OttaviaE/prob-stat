summary.marascuilo <-
function(obj, ...)
{
    k <- ncol(obj$tbl)
    if (is.null(dimnames(tbl))) {
        rownames(tbl) <- c(1:2)
        colnames(tbl) <- c(1:k)
    }
    cnms <- colnames(tbl)
    kk <- k*(k-1)/2
    coefs <- matrix(NA,kk,4)
    colnames(coefs) <- c("Diff","SE","chi-2","p")
    rownames(coefs) <- c(1:kk)
    kk <- 0
    for (i in 1:(k-1)) {
        for (j in ((i+1):k)) {
            kk <- kk+1
            coefs[kk,] <- c(obj$delta[i,j],sqrt(obj$varDif[i,j]),
                 obj$statistics[i,j],obj$p.value[i,j])
            rownames(coefs)[kk] <- paste(cnms[i],"-",cnms[j])
}}
    return(coefs)
}
