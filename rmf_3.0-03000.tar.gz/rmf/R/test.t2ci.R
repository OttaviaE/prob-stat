test.t2ci <-
function(media1=NA,ds1=NA,n1=NA,media2=NA,ds2=NA,n2=NA,
                      dati=NULL,gruppo=NULL,conf=0.95)
{
    umalpha <- conf
    if ((umalpha <0.4) | (umalpha>=1)) umalpha <- 0.95
    pr <- umalpha+(1-umalpha)/2

    if (is.null(dati)) {
       m1 <- media1
       m2 <- media2
       v1 <- ds1^2
       v2 <- ds2^2
    }

    if (!is.null(dati)) {
       x <- dati
       tg <- table(gruppo)
       x1 <- x[gruppo==names(tg[1])]
       x2 <- x[gruppo==names(tg[2])]
       d1 <- x1[!is.na(x1)]
       d2 <- x2[!is.na(x2)]
       m1 <- mean(d1)
       m2 <- mean(d2)
       v1 <- var(d1)
       v2 <- var(d2)
       n1 <- length(d1)
       n2 <- length(d2)
    }

    grl <- n1+n2-2
    dev1 <- v1*(n1-1)
    dev2 <- v2*(n2-1)
    devp <- dev1+dev2
    varp <- devp/grl
    vardif <- varp/n1 + varp/n2
    se <- sqrt(vardif)
    tt <- abs(m1-m2)/se
    p <- 2*pt(tt,grl,lower.tail=FALSE)
    tcr <- qt(pr,grl)
    ei <- (m1-m2)-tcr*se
    es <- (m1-m2)+tcr*se
    cat("Primo   campione: media =",m1," d.s. =",sqrt(v1)," n =",n1,"\n")
    cat("Secondo campione: media =",m2," d.s. =",sqrt(v2)," n =",n2,"\n")

    cat("\nVarianza congiunta =",varp," ES =",se,"\n")
    cat("Test t =",tt," g.l. =",grl," p-value =",p,"\n")
    cat("t critico = ",tcr,"  I.C. al ",umalpha*100,
        "% per la differenza: da ",ei," a ",es,"\n",sep="")

    vardif <- v1/n1 + v2/n2
    se <- sqrt(vardif)
    tt <- abs(m1-m2)/se
    num <- (v1/n1 + v2/n2)^2
    den <- (v1/n1)^2/(n1-1) + (v2/n2)^2/(n2-1)
    gdl <- num/den
    p <- 2*pt(tt,gdl,lower.tail=FALSE)
    tcr <- qt(pr,gdl)
    ei <- (m1-m2)-tcr*se
    es <- (m1-m2)+tcr*se
    cat("\nErrore standard della differenza =",se,"\n")
    cat("Test di Welch =",tt," g.l. =",gdl," p-value =",p,"\n")
    cat("t critico = ",tcr,"  I.C. al ",umalpha*100,
        "% per la differenza: da ",ei," a ",es,"\n",sep="")
}
