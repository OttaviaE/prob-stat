PrepHist <-
function(x,da,a,nclassi,destra)
{
   stp <- (a-da)/nclassi
   brk <- seq(da,a,stp)
   n <- table(cut(x,brk,right=destra))
   out <- list(breaks=brk,counts=n,intensities=n/sum(n))
   out
}
