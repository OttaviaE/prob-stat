tcc <-
function(m,n,vare)
{
    k <- length(m)
    if (length(n) != k) stop("Lunghezze non coincidenti.")
    if (is.null(names(m))) names(m) <- c(1:k)
    nms <- names(m)
    gle <- sum(n)-k
    nc <- k*(k-1)/2
    out <- matrix(nrow=nc,ncol=8)
    rownames(out) <- c(1:nc)
    kk <- 0
    for (i in 1:(k-1)) {
        for (j in (i+1):k) {
            ma <- m[i]
            mb <- m[j]
            se <- sqrt(vare/n[i]+vare/n[j])
            t <- abs(ma-mb)/se
            p <- pt(t,gle,lower.tail=FALSE)*2
            d <- ma-mb
            kk <- kk+1
            out[kk,] <- c(i,j,ma,mb,d,se,t,p)
            rownames(out)[kk] <- paste(nms[i],"-",nms[j])
}
}
    out <- out[,-c(1,2)]
    colnames(out) <- c("media","media","delta","SE","t","p")
    out <- list(out=out,"df"=gle)
    class(out) <- "tcc"
    return(out)
}
