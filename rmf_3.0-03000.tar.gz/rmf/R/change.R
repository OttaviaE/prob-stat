change <-
function (x, inp, out)
{
    if (length(inp) != length(out)) stop ("Lunghezza degli argomenti inp/out non coincidente")
    for (j in 1:length(inp)) x[x == inp[j]] <- out[j]
    x
}
