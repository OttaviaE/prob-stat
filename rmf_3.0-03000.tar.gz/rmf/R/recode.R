recode <-
function(x,y,z,na.rec=FALSE)
{
    if (length(y)!=length(z)) stop ("Lunghezze diverse.")
    w <- rep(NA,length(x))
    l <- length(y)
    for (i in 1:l){
        ok <- which(x==y[i])
        w[ok] <- z[i]
    }
    if (!na.rec) {
       ok <- which(is.na(w))
       w[ok] <- x[ok]        # ripristina il valore originario
    }
    w
}
