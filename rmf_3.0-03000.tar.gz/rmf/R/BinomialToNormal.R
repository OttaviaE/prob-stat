BinomialToNormal <-
function(n=10,p=0.5,da=0,a=n,dettaglio=FALSE,grafico=TRUE,...)
{
     if (n<1) n <- 10
     if (p<=0)       p <- 0.5
     if (p>=1)       p <- 0.5
     x <- c(da:a)
     y <- dbinom(x,n,p)
     e <- n*p
     v <- n*p*(1-p)
     xn1 <- x - 0.5
     xn2 <- x + 0.5
     if (grafico) {
        tit <- paste("Distribuzione Binomiale: n=",n,", p=",p,sep="")
        plot(x,y,type="h",ylab="f(x)",main=tit,...)
        curve(dnorm(x,mean=e,sd=sqrt(v)),add=TRUE)
     }
     if (dettaglio) {
        Fn <- pnorm(xn2,e,sqrt(v))
        yn <- c(Fn[1],diff(Fn))
        yy <- cumsum(dbinom(c(0:a),n,p))        
        if (da>0) yy <- yy[-c(0:da)] # lo zero � al posto uno
        if (da>0) yn[1] <- pnorm((da+0.5),e,sqrt(v))-pnorm((da-0.5),e,sqrt(v))
        out <- cbind(x,y,yn,yy,Fn)
        colnames(out) <- c("x","f(x)","n(x)","F(x)","N(x)")
        titolo("Distribuzione Binomiale approssimata con una Normale")
        cat("Numero delle prove      :",n,"\n")
        cat("Probabilita' di successo:",p,"\n")
        stampa(e,v,y)
        print(out)
     }
}
