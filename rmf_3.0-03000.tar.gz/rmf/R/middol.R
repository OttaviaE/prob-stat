middol <-
function (strdol, da = 1, n = 0)
{
    l <- nchar(strdol)
    if (length(n)==1) n <- rep(n,length(strdol))
    if (length(n)!=length(strdol)) stop ("Lunghezze non compatibili.")
    nok <- which(n==0)
    n[nok] <- l[nok]
    if (length(da)==1) da <- rep(da,length(strdol))
    if (length(da)!=length(strdol)) stop ("Lunghezze non compatibili.")
    a <- (da + n - 1)
    nok <- which(a>l)
    a[nok] <- l[nok]
    bdol <- substr(strdol, da, a)
    bdol
}
