Table <-
function(...)
{
    args <- list(...)
    largs <- length(args)
    if (largs == 0)   stop("Nessun argomento in input.")
    if (largs >  2)   stop("Troppi argomenti in input.")
    if (largs == 1) {
       tbl <- args[[1]]
       if (length(dim(tbl)) != 2) stop("L'argomento non e' una tabella bidimensionale.")
    }
    if (largs == 2) {
       vrig <- args[[1]]
       vcol <- args[[2]]
       tbl <- table(vrig,vcol)
    }
    cla <- class(tbl)
    trig <- rowSums(tbl,na.rm=TRUE)
    tmp <- cbind(tbl,trig)
    tcol <- colSums(tmp,na.rm=TRUE)
    tmp <- rbind(tmp,tcol)
    nrig <- nrow(tmp)
    ncol <- ncol(tmp)
    rownames(tmp)[nrig] <- "Tot."
    colnames(tmp)[ncol] <- "Tot."
    class(tmp) <- cla
    return(tmp)
}
