quartili <-
function(x) quantile(x,probs = seq(0, 1, 0.25), na.rm = TRUE, type=1)
