summary.Tango <-
function(obj, ...)
{
    ll <- obj[1]
    ul <- obj[2]
    b  <- obj[3]
    c  <- obj[4]
    n  <- obj[5]

    conf    <- obj[6]
    niter.b <- obj[7]
    niter.c <- obj[8]

    cat("Intervallo di confidenza di Tango per la\ndifferenza di due proporzioni dipendenti\n")
    cat("\nLivello di confidenza:",conf)
    cat("\nDimensione del campione ",n)
    cat("\nCoppie discordanti (b,c)",b,c)
    cat("\nDifferenza fra le due proporzioni",(c-b)/n)
    cat("\nIntervallo di confidenza: da",ll,"a",ul)
    cat("\nNumero di iterazioni eseguite:",niter.b,niter.c,"\n")
}
