covarianza <-
function(x,y) cov(x, y, use = "complete.obs")
