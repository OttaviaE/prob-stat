potenza.prop <-
function(p0,p1,alfa,n)
{
    z   <- -qnorm(alfa/2)
    sigma0 <- sqrt(p0*(1-p0))
    sigma1 <- sqrt(p1*(1-p1))
    lwr <- p0 - z*sigma0/sqrt(n)
    upr <- p0 + z*sigma0/sqrt(n)
    pl  <- pnorm(lwr,p1,sigma1/sqrt(n))
    pu  <- pnorm(upr,p1,sigma1/sqrt(n),lower.tail=FALSE)
    p   <- pl + pu
    return(p)
}
