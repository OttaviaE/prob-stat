Fblr <-
function(Y,nrep=10000)
{
    rsmp <- function(y) sample(y,length(y),replace=FALSE)
    aovb <- function(Y) {
        n <- nrow(Y); k <- ncol(Y); N <- n*k
        devt <- sum((Y - mean(Y))^2)
        devf <- n*sum((colMeans(Y) - mean(Y))^2)
        devb <- k*sum((rowMeans(Y) - mean(Y))^2)
        devr <- devt - (devf+devb)
        varf <- devf/(k-1)
        varr <- devr/(N-1-(k-1)-(n-1))
        varf/varr
    }

    n <- nrow(Y)
    out <- numeric(nrep)
    for (i in 1:(nrep-1)) {
        YY <- t(apply(Y,1,rsmp))
        out[i] <- aovb(YY)
    }
    out[nrep] <- aovb(Y)
    attr(out,"Method") <- "Test di permutazione per k campioni dipendenti"
    attr(out,"gruppi") <- ncol(Y)
    class(out) <- "tperm"
    out
}
