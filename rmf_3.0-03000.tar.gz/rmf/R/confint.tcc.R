confint.tcc <-
function(obj, parm, level = 0.95, ...)
{
    if (level<0.5 | level>=1) level <- 0.95
    tmp <- obj[[1]]
    nc <- nrow(tmp)
    alfa <- 1 - level
    a2 <- (alfa/nc)/2
    gle <- obj[[2]]
    tb <- qt(a2,gle,lower.tail=FALSE)
    se <- tmp[,4]
    me <- tb*se
    delta <- tmp[,3]
    lwr <- delta - me
    upr <- delta + me
    out <- cbind(tmp[,c(1,2,4,3)],lwr,upr)
    return(out)
}
