sim <-
function (n = 10, dati = c(0:9), nrep = 10000, grafico = TRUE)
{
    nobs <- n
    nsim <- nrep
    pop <- dati[!is.na(dati)]
    npop <- length(pop)
    prob <- rep(1/npop, npop)
    mu <- mean(pop)
    sigma <- sqrt(var(pop) * (npop - 1)/npop)

    xmean <- replicate(nsim,mean(sample(pop,nobs,replace=TRUE,prob=prob)))

    xm <- mean(xmean)
    xv <- var(xmean)

    cat("Simulazione di ", nsim, " campioni, ciascuno di dimensione ",
        nobs, ",\n", sep = "")
    cat("estratti da una distribuzione empirica con media ",
        mu, " e varianza ", sigma^2, "\n", sep = "")
    cat("La media    delle medie e' ", xm, "\n")
    cat("La varianza delle medie e' ", xv, "\n")
    cat("La d.s.     delle medie e' ", sqrt(xv), "\n")
    if (nsim >= 10000 & grafico)
        AddNorm(xmean, mu = mu, se = sigma/sqrt(n))
    xmean
}
