tc <-
function(x,y,esatto=FALSE,label=FALSE){
     vRig <- deparse(substitute(x))
     vCol <- deparse(substitute(y))
     tmp <- table(x,y)
     trig <- apply(tmp,1,sum)
     tcol <- apply(tmp,2,sum)
     tmp <- tmp[trig>0,]
     tbl <- tmp[,tcol>0]
     nrig <- dim(tbl)[1]
     ncol <- dim(tbl)[2]
     tgen <- sum(tbl)
     if (tgen==0) stop("LA TABELLA E' VUOTA!!!!!")
     trig <- margin.table(tbl,1)
     tcol <- margin.table(tbl,2)
     if (sum(trig==0)>0) stop("ALMENO UNA RIGA E' VUOTA!!!!!")
     if (sum(tcol==0)>0) stop("ALMENO UNA COLONNA E' VUOTA!!!!!")
     options(warn=-1); cq <- chisq.test(tbl); options(warn=0)
     nmin5 <- sum(cq$exp<5)
     nmin1 <- sum(cq$exp<1)
     glib <- cq$par[[1]]
     tef <- NULL
     if (glib==1 | esatto==TRUE) tef <- fisher.test(tbl)
     prRig <- prop.table(tbl,1)
     prCol <- prop.table(tbl,2)

     out <- list(vRig=vRig,vCol=vCol,
                 tbl=tbl,cq=cq,nmin5=nmin5,nmin1=nmin1,
                 glib=glib,tef=tef,prRig=prRig,prCol=prCol,
                 missing=length(x)-sum(tbl),label=label)

     class(out) <- "tc"
     return(out)
}
