potenza <-
function(mu0,mu1,sigma,alfa,n)
{
    z   <- -qnorm(alfa/2)
    lwr <- mu0 - z*sigma/sqrt(n)
    upr <- mu0 + z*sigma/sqrt(n)
    pl  <- pnorm(lwr,mu1,sigma/sqrt(n))
    pu  <- pnorm(upr,mu1,sigma/sqrt(n),lower.tail=FALSE)
    p   <- pl + pu
    return(p)
}
