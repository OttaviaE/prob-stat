print.WW <-
function(ww)
{
    cat("Totale osservazioni nei due gruppi:",ww[1],ww[2],"\n")
    cat("Numero di run, valore atteso e d.s.:",ww[3],ww[4],ww[5],"\n")
    cat("Test z e p-value:",ww[6],ww[7],"\n")
}
