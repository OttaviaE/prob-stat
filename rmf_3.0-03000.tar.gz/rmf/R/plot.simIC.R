plot.simIC <-
function(X, Y, ...)
{
     nrep <- X$nrep
     conf <- X$conf
     n <- X$n
     mu <- X$mu
     sigma <- X$sigma
     out <- X$out
     cih <- out[,4]
     cil <- out[,3]
     a <- out[,5]

     n <- nrow(out)
     y <- c(1:n)
     tit <- paste(nrep," intervalli di confidenza al ",(conf*100),sep="")
     tit <- paste(tit,"%\nper la media di una normale",sep="")
     plot(c(out[1,3],out[n,4]),c(y[1],y[n]),type="n",
          ylab="numero dell'intervallo",xlab="x",main=tit)
     abline(v=mu)
     out <- out[order(out[,6]),]
     for (i in 1:n) points(c(out[i,3],out[i,4]),c(y[i],y[i]),type="l")
}
