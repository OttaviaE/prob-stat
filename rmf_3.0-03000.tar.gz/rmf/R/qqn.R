qqn <-
function (x, stand = FALSE, ident = FALSE, ...)
{
    if (stand) x <- scale(x)
    if (ident) x <- scale(x)
    qqnorm(x, ...)
    if (ident) abline(0, 1) else
       qqline(x)
}
