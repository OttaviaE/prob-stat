simnorm <-
function(n=10,mu=0,sigma=1,nrep=10000,grafico=TRUE)
{
     nobs <- n
     nsim <- nrep
     xmean <- replicate(nsim,mean(rnorm(nobs,mu,sigma)))
     xm <- mean(xmean)
     xv <- var(xmean)
     ds <- sqrt(xv)
     se <- sigma/sqrt(nobs)
     cat("Simulazione di ",nrep," campioni, ciascuno di dimensione ",n,",\n",sep="")
     cat("estratti da una normale con media",mu,"e deviazione standard",sigma,"\n")
     cat("La media    delle medie e' ",xm,"\n")
     cat("La varianza delle medie e' ",xv,"\n")
     cat("La d.s.     delle medie e' ",sqrt(xv),"\n")
     if (nrep>=10000 & grafico) AddNorm(xmean,mu=mu,se=sigma/sqrt(n))
     xmean
}
