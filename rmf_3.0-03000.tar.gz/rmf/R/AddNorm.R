AddNorm <-
function(xmean,mu,se,qqp=TRUE)
{
         if (qqp) {
            qqnorm(xmean)
            qqline(xmean)
         } else {
            hist(xmean,50,den=-1,freq=FALSE,xlab="media del campione")
            Curve(dnorm(x,mean=mu,sd=se),add=TRUE)
         }
}
