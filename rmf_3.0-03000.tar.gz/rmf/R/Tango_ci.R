Tango_ci <-
function(b,c,n,conf=0.95,maxit=100,eps=0.0000001)
{
   pa <- 2*n
   z <- qnorm(1-(1-conf)/2)

   if (c == n) {ul <- 1}
   else {
     proot <- (c-b)/n
     dp <- 1-proot
     niter <- 1
     while (niter <= maxit){
       dp <- 0.5*dp
       up2 <- proot+dp
       pb <- - b - c + (2*n-c+b)*up2
       pc <- -b*up2*(1-up2)
       q21 <- (sqrt(pb^2-4*pa*pc)-pb)/(2*pa)
       score <- (c-b-n*up2)/sqrt(n*(2*q21+up2*(1-up2)))
       if (abs(score)<z){proot <- up2}
       niter <- niter+1
       if ((dp<eps) || (abs(z-score)<eps)){
          ul <- up2
          niter.c <- niter
          break
       }
       if (niter > maxit) warning("Numero massimo di iterazioni raggiunto.")
     }
   }

   if (b == n) {ll <- -1}
   else {
     proot <- (c-b)/n
     dp <- 1+proot
     niter <- 1
     while (niter <= maxit){
       dp <- 0.5*dp
       low2 <- proot-dp
       pb <- - b - c + (2*n-c+b)*low2
       pc <- -b*low2*(1-low2)
       q21 <- (sqrt(pb^2-4*pa*pc)-pb)/(2*pa)
       score <- (c-b-n*low2)/sqrt(n*(2*q21+low2*(1-low2)))
       if (abs(score) < z){proot <- low2}
       niter <- niter+1
       if ((dp<eps) || (abs(z-score)<eps)){
          ll <- low2
          niter.b <- niter
          break
       }
       if (niter > maxit) warning("Numero massimo di iterazioni raggiunto.")
     }
   }
   out <- c(ll,ul,b,c,n,conf,niter.b,niter.c)
   class(out) <- "Tango"
   return(out)
}
