wilson.2prop <-
function(a,m,b,n,conf=0.95)
{
    z <- qnorm((1-conf)/2,lower.tail=FALSE)

    tmp <- wilson.1prop(a,m); l1 <- tmp[1]; u1 <- tmp[2]
    tmp <- wilson.1prop(b,n); l2 <- tmp[1]; u2 <- tmp[2]

    dlt <- z * sqrt((l1*(1-l1)/m) + (u2*(1-u2)/n))
    eps <- z * sqrt((u1*(1-u1)/m) + (l2*(1-l2)/n))

    tht <- (a/m) - (b/n)
    cil <- tht - dlt
    ciu <- tht + eps

    out <- list(dati=c(a,m,b,n),conf=conf,ic=c(tht,cil,ciu))
    class(out) <- "wilson2"
    return(out)
}
