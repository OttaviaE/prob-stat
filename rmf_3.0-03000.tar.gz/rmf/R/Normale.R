Normale <-
function(mu=0,sigma=1,add=FALSE,tit=FALSE,...)
{
     if (tit) tit <- paste("Distribuzione Normale\n(media=",mu," e varianza=",format(sigma^2),")",sep="") else tit <- NULL
     if (!add) {
         xmn <- mu - 3.5*sigma; xmx <- mu + 3.5*sigma
         plot(c(xmn,xmx),c(0,dnorm(mu,mu,sigma)),type="n",main=tit,...)
     }
     Curve(dnorm(x,mean=mu,sd=sigma),add=add,main=tit,...)
     abline(h=0)
}
