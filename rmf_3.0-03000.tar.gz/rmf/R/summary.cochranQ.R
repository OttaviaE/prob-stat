summary.cochranQ <-
function(out, ...)
{
    cat("Cochran's Q test for dependent samples\n\n")
    cat("Proporzioni a confronto:",out$prop,"\n\n")
    cat("Chi quadrato = ",out$statistic,
        ", df = ", out$df,
        ", p-value = ", out$p.val, "\n",sep="")
    cat("Osservazioni complete = ",out$n,
        ", osservazioni mancanti = ",out$missing,"\n",
        "Osservazioni con totale 0 o massimo = ",out$nzero,", ",out$nuno,
        "\n",sep="")
}
