simbino <-
function(nobs=10,n=10,p=0.5,nsim=10000,grafico=TRUE)
{
     xmean <- replicate(nsim,mean(rbinom(nobs,n,p)))
     xm <- mean(xmean)
     xv <- var(xmean)
     ds <- sqrt(xv)
     se <- ds/sqrt(nobs)
     mu <- n*p; sigma <- sqrt(n*p*(1-p))
     cat("Simulazione di ",nsim," campioni, ciascuno di dimensione ",nobs,",\n",sep="")
     cat("estratti da una binomiale (n=",n,", p=",p,")\n",sep="")
     cat("La media    delle medie e' ",xm,"\n")
     cat("La varianza delle medie e' ",xv,"\n")
     cat("La d.s.     delle medie e' ",sqrt(xv),"\n")
     if (nsim>=10000 & grafico) AddNorm(xmean,mu=mu,se=sigma/sqrt(n))
     xmean
}
