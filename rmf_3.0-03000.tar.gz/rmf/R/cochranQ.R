cochranQ <-
function(mat)
{
    if (!is.matrix(mat)) mat <- as.matrix(mat)
    if (ncol(mat)<2) stop("Sono necessari almeno due gruppi.")

    tmp <- rowSums(mat)
    ok <- which(!is.na(tmp))
    msng <- nrow(mat) - length(ok)
    mat <- mat[ok,]
    if (nrow(mat)<2) stop("Numero di osservazioni insufficiente.")

    k <- ncol(mat)
    R <- rowSums(mat)
    nzero <- sum(R == 0)
    nuno  <- sum(R == k)

    T <- colSums(mat)
    Tbar <- mean(T)
    p <- rowMeans(mat)
    sigma2 <- sum(p*(1-p))*k/(k-1)
    z <- (T-Tbar)/sqrt(sigma2)
    Q <- sum(z^2)
    df <- k - 1
    pval <- pchisq(Q,df,lower.tail=FALSE)
    out <- list(statistic = Q, df = df, p.value = pval,
                gruppi=k,T=T,z=z,sigma=sqrt(sigma2),prop=colMeans(mat),
                n=nrow(mat),nzero=nzero,nuno=nuno,missing=msng)
    class(out) <- "cochranQ"
    return(out)
}
