test.prop <-
function (successi, n, p0 = NA, conf = 0.95)
{

wilson <- function(x,n,z)
{
    ph <- x/n
    aa <- z^2/(2*n)
    bb <- (ph*(1-ph)+z^2/(4*n))/n
    den <- 1+z^2/n
    plow <- (ph + aa - z*sqrt(bb))/den
    pupp <- (ph + aa + z*sqrt(bb))/den
    c(plow,pupp)
}

    umalpha <- conf
    if ((umalpha < 0.4) | (umalpha >= 1))
        umalpha <- 0.95
    xx <- successi
    nn <- n
    if ((n < 1) | (n < successi))
        stop("Parametro/i non valido/i.")
    p <- xx/nn
    v <- p * (1 - p)/nn
    se <- sqrt(v)
    pr <- umalpha + (1 - umalpha)/2
    zcr <- qnorm(pr)
    me <- zcr * se
    ei <- p - me
    es <- p + me
    cat("stima di p =", p, " n =", nn, "\n")
    cat("ES =", se, " margine di errore =", me, "\n")
    cat("I. C. appross.  al ", umalpha * 100, "% per p: da ",
        ei, " a ", es, "\n", sep = "")

    tmp <- wilson(xx,nn,zcr)
    cat("I. C. di Wilson al ", umalpha * 100, "% per p: da ",
        tmp[1], " a ", tmp[2], "\n", sep = "")

    xxx <- binom.test(xx, nn, conf.level = umalpha)$conf.int
    cat("I. C. esatto    al ", umalpha * 100, "% per p: da ",
        xxx[1], " a ", xxx[2], "\n", sep = "")
    if (!missing(p0)) {
        v <- p0 * (1 - p0)/nn
        se <- sqrt(v)
        z <- (p - p0)/se
        pval <- pnorm(abs(z))
        pval <- (1 - pval) * 2
        bint <- binom.test(xx, nn, p = p0)
        xxx <- bint$p.value
        cat("\nIpotesi nulla: p =", p0, " ES sotto H0 =", se,
            "\n")
        cat("Test z approssimato:", z, " p-value =", pval, "\n")
        cat("Test esatto binomiale: p-value =", xxx, "\n")
    }
}
