test.t1c <-
function(media=NA,ds=NA,n=0,mu0=NA,dati=NULL,conf=0.95) 
{
    x <- dati
    if (!is.null(x)) {
       ok <- which(!is.na(x))
       tmp <- x[ok]
       m1 <- mean(tmp)
       v1 <- var(tmp)
       n1 <- length(tmp)
    }
    if (is.null(x)) {
        m1 <- media
        v1 <- ds^2
        n1 <- n
    }

    if ((v1<=0) | (n1<=0)) stop("Parametro/i non valido/i.")

    umalpha <- conf
    if ((umalpha <0.4) | (umalpha>=1)) umalpha <- 0.95

    ds1 <- sqrt(v1)
    se <- sqrt(v1/n1)
    grl <- n1-1

    pr <- umalpha+(1-umalpha)/2
    tcr <- qt(pr,grl)
    ei <- m1-tcr*se
    es <- m1+tcr*se
    cat("media =",m1," d.s. =",sqrt(v1)," ES =",se," n =",n1,
        " t critico =",tcr,"\n")
    cat("Intervallo di confidenza al ",umalpha*100,
        "% per la media: da ",ei," a ",es,"\n",sep="")

    if (!is.na(mu0)) {
       tt <- (m1-mu0)/se
       pvalt <- pt(abs(tt),grl)
       pvalt <- (1-pvalt)*2
       cat("\nIpotesi nulla: mu =",mu0,"\n")
       cat("Test t:",tt," g.l. =",grl," p-value =",pvalt,"\n")
    }
}
