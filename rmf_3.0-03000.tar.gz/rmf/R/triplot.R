triplot <-
function(X,prop=FALSE,coord=FALSE,
                    xlim=c(0,1),ylim=c(0,sqrt(3)/2),
                    punti=FALSE,cex.vert=0.7,cex.text=0.6)
{
    if (prop) P <- X else P <- t(apply(X,1,prop.table))
    if (is.null(colnames(X))) colnames(X) <- as.character(1:ncol(X))
    if (is.null(rownames(X))) rownames(X) <- as.character(1:nrow(X))

    h <- sqrt(3)/2
    xtra <- c(0.5,0,1); ytra <- c(h,0,0)
    plot(xtra,ytra,type="n",xlim=xlim,ylim=ylim,axes=FALSE,xlab="",ylab="")
    lines(c(0  ,1  ),c(0,0))
    lines(c(0  ,0.5),c(0,h))
    lines(c(0.5,1  ),c(h,0))
    text(0.5,h,colnames(X)[1],cex=cex.vert)
    text(0  ,0,colnames(X)[2],cex=cex.vert)
    text(1  ,0,colnames(X)[3],cex=cex.vert)

    out <- matrix(NA,nrow=nrow(P),ncol=2)
    for (i in 1:nrow(P)){
        z <- P[i,]
        xx <- sum(xtra*z)
        yy <- sum(ytra*z)
        out[i,1] <- xx
        out[i,2] <- yy
        if(punti) points(xx,yy)
        nome <- rownames(X)[i]
        text(xx,yy,nome,cex=cex.text)
    }
    if (coord) return(out)
}
