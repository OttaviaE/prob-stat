WW <-
function(x,g)
{
    cc <- complete.cases(data.frame(x,g))
    x <- x[cc]; g <- g[cc]
    l <- length(x)
    if (sum(duplicated(x)) != 0) warning("Esistono valori duplicati.")
    o <- order(x); x <- x[o]; g <- g[o]
    tbl <- table(g)
    if (length(tbl) != 2) stop("Numero di gruppi a confronto diverso da 2.")
    tot <- table(g); n <- sum(tot)
    nt <- tot[1]; nc <- tot[2]
    mu <- 1 + 2*(nt*nc)/n
    num <- 2*nt*nc*(2*nt*nc-nt-nc)
    den <- n^2*(n-1)
    ds <- sqrt(num/den)
    nrun <- run(g)
    z <- (nrun - mu)/ds
    pval <- pnorm(abs(z),lower.tail=FALSE)*2

    ww <- numeric(7)
    ww[1] <- tot[1]; ww[2] <- tot[2]
    ww[3] <- nrun
    ww[4] <- mu; ww[5] <- ds
    ww[6] <- z; ww[7] <- pval
    class(ww) <- "WW"
    return(ww)
}
