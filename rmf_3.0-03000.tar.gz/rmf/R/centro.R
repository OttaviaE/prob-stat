centro <-
function(col="red",pch=19)
{
    h <- sqrt(3)/2
    xtra <- c(0.5,0,1); ytra <- c(h,0,0)
    xx <- sum(xtra*rep(1/3,3))
    yy <- sum(ytra*rep(1/3,3))
    points(xx,yy,col=col,pch=pch)
}
