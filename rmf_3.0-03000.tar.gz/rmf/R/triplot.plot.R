triplot.plot <-
function(xlim=c(0,1),ylim=c(0,sqrt(3)/2),
                         vertici=TRUE,cex.vert=0.7,...)
{
    h <- sqrt(3)/2
    xtra <- c(0.5,0,1); ytra <- c(h,0,0)
    plot(xtra,ytra,type="n",xlim=xlim,ylim=ylim,axes=FALSE,xlab="",ylab="",...)
    lines(c(0  ,1  ),c(0,0))
    lines(c(0  ,0.5),c(0,h))
    lines(c(0.5,1  ),c(h,0))
    if (vertici) {
       text(0.5,h,"1",cex=cex.vert)
       text(0  ,0,"2",cex=cex.vert)
       text(1  ,0,"3",cex=cex.vert)}
}
