amp.n <-
function(p,eps,conf=0.95,nstart=NULL)
{
  alfa <- 1-conf
  z <- qnorm(alfa/2,lower.tail=FALSE)
  n <- (2*z)^2*p*(1-p)/eps^2
  n <- trunc(n)
  cat("Valore teorico",n,"\n")
  if (!is.null(nstart)) n <- nstart
  if (n<1) stop("Numerosita' di partenza nulla.")
  num <- trunc(n*p)+1
  xxx <- binom.test(num, n, conf.level = conf)$conf.int
  amp <- xxx[2] - xxx[1]
  if (amp < eps) n <- trunc(n/2)
  repeat {
    num <- trunc(n*p)+1
    xxx <- binom.test(num, n, conf.level = conf)$conf.int
    amp <- xxx[2] - xxx[1]
    if (amp <= eps) break
    n <- n+1
}
  cat("n =",n,"p =",num/n,"ampiezza",amp,"IC: da",xxx[1],"a",xxx[2],"\n")
}
