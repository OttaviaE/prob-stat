nomis <-
function(x) sum(is.na(x))
