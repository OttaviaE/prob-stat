simTest <-
function(n,mu0,mu1=NULL,sigma,alpha=0.05,nrep)
{
     if (missing(alpha)) alpha <- 0.05
     if (alpha > 1) alpha <- alpha/100
     nobs <- n
     nsim <- nrep
     a2    <- (1-alpha)+alpha/2
     xm    <- c(1:nsim)
     se    <- c(1:nsim)
     z     <- c(1:nsim)
     sem   <- sigma/sqrt(nobs)
     pr    <- (1-alpha)+alpha/2
     zcrit <- qnorm(pr)
     za2 <- zcrit
     if (is.null(mu1)) munorm <- mu0 else munorm <- mu1

     for (i in 1:nsim) {
         x <- rnorm(nobs,munorm,sigma)
         xm[i] <- mean(x)
         se[i] <- sem
         z[i] <- (xm[i] - mu0)/se[i]
     }
     a <- 1-((abs(z)<=za2)*1)
     nrig <- c(1:nsim)
     o    <- order(xm)
     xm   <- xm[o]
     se   <- se[o]
     z    <- z[o]
     a    <- a[o]
     nrig <- nrig[o]
     xx   <- data.frame(xm,se,z,a,nrig)
     out <- list(alpha=alpha,mu0=mu0,mu1=mu1,zcrit=zcrit,sem=sem,n=n,za2=za2,nrep=nrep,a=a,xx=xx)
     class(out) <- "simTest"
     out
}
