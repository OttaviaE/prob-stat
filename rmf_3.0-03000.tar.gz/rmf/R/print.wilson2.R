print.wilson2 <-
function(obj, ...) print(obj$ic)
