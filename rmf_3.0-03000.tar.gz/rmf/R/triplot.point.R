triplot.point <-
function(X,label=FALSE,prop=FALSE,cex.text=0.6,...)
{
    if (!is.matrix(X)) X <- matrix(X,ncol=3)
    if (is.null(rownames(X))) rownames(X) <- as.character(1:nrow(X))
    if (prop) P <- X else P <- t(apply(X,1,prop.table))
    if (!is.matrix(P)) P <- matrix(P,ncol=3)

    h <- sqrt(3)/2
    xtra <- c(0.5,0,1); ytra <- c(h,0,0)

    for (i in 1:nrow(P)){
        z <- P[i,]
        xx <- sum(xtra*z)
        yy <- sum(ytra*z)
        points(xx,yy,...)
        if (label) text(xx,yy,rownames(X)[i],cex=cex.text)
    }
}
