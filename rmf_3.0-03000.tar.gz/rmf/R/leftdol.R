leftdol <-
function(strdol,k) substr(strdol,1,k)
