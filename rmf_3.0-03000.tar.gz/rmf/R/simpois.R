simpois <-
function(n=10,lambda=10,nrep=10000,grafico=TRUE)
{
     nobs <- n
     nsim <- nrep
     xmean <- replicate(nsim,mean(rpois(nobs,lambda)))
     xm <- mean(xmean)
     xv <- var(xmean)
     ds <- sqrt(xv)
     se <- ds/sqrt(nobs)
     mu <- lambda; sigma <- sqrt(lambda)
     cat("Simulazione di ",nsim," campioni, ciascuno di dimensione ",nobs,",\n",sep="")
     cat("estratti da una Poisson (lambda=",lambda,")\n",sep="")
     cat("La media    delle medie e' ",xm,"\n")
     cat("La varianza delle medie e' ",xv,"\n")
     cat("La d.s.     delle medie e' ",sqrt(xv),"\n")
     if (nsim>=10000 & grafico) AddNorm(xmean,mu=mu,se=sigma/sqrt(n))
     xmean
}
