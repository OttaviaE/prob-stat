media <-
function(x) {
   d <- x[!is.na(x)]
   dm <- length(x)-length(d)
   if (dm>0) cat("Osservazioni mancanti:",dm,"\n")
   mean(d)
}
