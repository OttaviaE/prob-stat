summarize <-
function(x)
{
     x <- as.data.frame(x)
     idvar <- c(1:(dim(x)[2]))
     cls <- Class(x); ok <- which(cls=="N")
     x <- x[,ok]
     if (is.null(dim(x))) x <- as.data.frame(x)
     idvar <- idvar[ok]
     xme <- apply(x,2,mean,na.rm=TRUE)
     xds <- apply(x,2,sd,na.rm=TRUE)
     xmd <- apply(x,2,median,na.rm=TRUE)
     xmn <- apply(x,2,min,na.rm=TRUE)
     xmx <- apply(x,2,max,na.rm=TRUE)
     msn <- apply(x,2,nomis)
     nob <- nrow(x) - msn
     out <- cbind(idvar,xme,xds,xmd,xmn,xmx,nob,msn)
     colnames(out) <- c("nv","media","d.s.","mediana",
        "minimo","massimo","nov","msng")
     out
}
