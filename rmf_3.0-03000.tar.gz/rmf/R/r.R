r <-
function(x,y)
{
   erre <- cor(x,y,use="compl",method="pearson")
   fit <- lm(y~x)
   n <- fit$df+2
   varr <- (1-erre^2)/(n-2)
   ttest <- abs(erre)/sqrt(varr)
   pval <- 2 * pt(ttest,(n-2),lower.tail=FALSE)
   cat("Coefficiente di correlazione lineare:",erre,"\n")
   cat("Numero di coppie di osservazioni    :",n,"\n")
   cat("Test t per l'assenza di correlazione lineare:",ttest,"\n")
   cat("p-value =",pval,"\n")
}
