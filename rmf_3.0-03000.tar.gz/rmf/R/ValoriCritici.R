ValoriCritici <-
function(alpha=0.05,mu=0,sigma=1,density=20,angle=45,color=NA)
{
     if (alpha>0.5) alpha <- (1-alpha)
     a2 <- alpha/2;      z1 <- qnorm(a2,mu,sigma)
     a2 <- (1-alpha)+a2; z2 <- qnorm(a2,mu,sigma)

     Normale(mu=mu, sigma=sigma)

     xda <- mu - 3.5*sigma
     FillNorm(xda,z1,mu,sigma,density,angle,color)
          
     xda <- z2; xa <- mu + 3.5*sigma
     FillNorm(z2,xa,mu,sigma,density,angle,color)
    
     out1 <- "I valori critici che individuano un'area nelle due code uguale a"
     out2 <- paste(alpha,"sono",z1,"e",z2)
     out <- paste(out1,out2)
     print(out) 
}
