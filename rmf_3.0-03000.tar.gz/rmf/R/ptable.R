ptable <-
function(x,y,margin=2)
{
   tbl <- table(x,y)
   nr <- nrow(tbl); nc <- ncol(tbl); glib <- 0
   if ( (nr>1) & (nc>1) ) glib <- (nr-1)*(nc-1)
   if (glib>0) cq <- chisq.test(tbl)
   pcr <- round(prop.table(tbl,1)*1000,0)
   pcc <- round(prop.table(tbl,2)*1000,0)
   if (margin==1) {
      tot <- apply(tbl,2,sum)
      pmr <- round(tot/sum(tot)*1000,0)
      tbl <- rbind(pcr,pmr)
      rdol <- "Frequenze (per mille) condizionate sui totali di riga\n"      
   }
   if (margin==2) {
      tot <- apply(tbl,1,sum)
      pmc <- round(tot/sum(tot)*1000,0)
      tbl <- cbind(pcc,pmc)
      rdol <- "Frequenze (per mille) condizionate sui totali di colonna\n"      
   }
   cat(rdol)   
   cat("Chi quadrato =",cq$stat,", df =",glib," p-value =",cq$p.val,"\n")   
   tbl
}
