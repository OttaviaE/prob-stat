simIC <-
function(n=10,mu=0,sigma=1,conf=0.95,nrep=20)
{
     umalpha <- conf
     if (umalpha > 1) umalpha <- umalpha/100
     alpha <- umalpha
     nobs <- n
     nsim <- nrep
     a2 <- alpha+(1-alpha)/2
     za2 <- qnorm(a2,0,1)

     xm <- rep(NA,nsim)
     for (i in 1:nsim) {
         x <- rnorm(nobs,mu,sigma)
         xm[i] <- mean(x)
     }
     se <- rep((sigma/sqrt(nobs)),nsim)
     k <- za2 * se
     cil <- xm - k
     cih <- xm + k

     a <- (cil <= mu)*(mu <= cih)

     nrig <- c(1:nsim)
     o    <- order(cih)
     xm   <- xm[o]
     se   <- se[o]
     cil  <- cil[o]
     cih  <- cih[o]
     a    <- a[o]
     nrig <- nrig[o]

     out   <- cbind(xm,se,cil,cih,a,nrig)
     colnames(out) <- c("media","ES","estr. inf.","estr. sup.","flag","camp. n.")

     obj <- list(nrep=nrep,conf=conf,n=n,mu=mu,sigma=sigma,out=out)
     class(obj) <- "simIC"
     return(obj)
}
