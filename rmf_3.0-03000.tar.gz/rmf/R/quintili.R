quintili <-
function(x) quantile(x,probs = seq(0, 1, 0.20), na.rm = TRUE, type=1)
