summary.tperm <-
function(x, ...)
{
    n <- length(x)
    y <- abs(x[n])
    att <- attributes(x)$Method
    cat(att,"\n")
    if (att == "Test di permutazione per dati appaiati") {
        pval <- (sum(x >= y) + sum(x <= -y))/n
        cat("Risultato originale: t =",x[n],"\n")
        cat("p-value a 2 code dopo",n,"ricampionamenti:",pval,"\n")
    }
    if (att == "Test di permutazione per k campioni dipendenti") {
        pval <- sum(x >= y)/n
        cat("Numero di campioni:",attributes(x)$gruppi,"\n")
        cat("Risultato originale: F =",x[n],"\n")
        cat("p-value dopo",n,"ricampionamenti:",pval,"\n")
    }

}
