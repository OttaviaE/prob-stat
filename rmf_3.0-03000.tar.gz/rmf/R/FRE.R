FRE <-
function(y,...)
{
tbl <- table(y)
n <- sum(tbl)
tbl <- cumsum(tbl)/n * 100
np <- length(tbl) - 1
xx <- names(tbl)
    for (i in 1:np) {
        x <- c(xx[i], xx[i + 1])
        y <- c(tbl[i], tbl[i])
        lines(x, y, ...)
        x <- c(xx[i + 1], xx[i + 1])
        y <- c(tbl[i], tbl[i + 1])
        lines(x, y, ...)
    }
}
