simunifc <-
function(n=10,da=0,a=1,nrep=10000,grafico=TRUE)
{
     nobs <- n
     nsim <- nrep
     xmean <- replicate(nsim,mean(runif(n,min=da,max=a)))
     xm <- mean(xmean)
     xv <- var(xmean)
     ds <- sqrt(xv)
     cat("Simulazione di ",nrep," campioni, ciascuno di dimensione ",n,",\n",sep="")
     cat("estratti da una distribuzione uniforme continua fra",da,"e",a,"\n")
     cat("La media    delle medie e' ",xm,"\n")
     cat("La varianza delle medie e' ",xv,"\n")
     cat("La d.s.     delle medie e' ",sqrt(xv),"\n")
     if (nrep>=10000 & grafico) AddNorm(xmean,mu=0.5,se=sqrt(1/(12*n)))
     xmean
}
