swap <-
function(x,a,b)
{
   tmp <- (x==a)*b + (x==b)*a
   k <- which(tmp==0)
   tmp[k] <- x[k]
   tmp
}
