info.xls <-
function(NomeFile)
{
    con <- odbcConnectExcel(NomeFile)
    out <- sqlTables(con)
    odbcCloseAll()
    out
}
