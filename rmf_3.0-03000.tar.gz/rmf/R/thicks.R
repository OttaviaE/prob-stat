thicks <-
function(eps=0.005)
{
    h <- sqrt(3)/2
    xtra <- c(0.5,0,1); ytra <- c(h,0,0)

    # base del triangolo
    x1 <- rep(0,9);x2 <- c(1:9)/10;x3 <- 1-(x1+x2)
    P <- cbind(x1,x2,x3)
    for (i in 1:nrow(P)) {
        z <- P[i,]
        xx <- sum(xtra*z)
        yy <- sum(ytra*z)
        x <- c(xx,xx)
        y <- c(yy-eps,yy+eps)
        lines(x,y)
    }

    # lato obliquo destro
    x1 <- c(1:9)/10;x2 <- rep(0,9);x3 <- 1-(x1+x2)
    P <- cbind(x1,x2,x3)
    for (i in 1:nrow(P)) {
        z <- P[i,]
        xx <- sum(xtra*z)
        yy <- sum(ytra*z)
        x1 <- xx-eps
        x2 <- xx+eps
        x <- c(x1,x2)
        b <- tan(pi/3); b <- 0.7
        a <- yy - b*xx
        y <- a + b*x
        lines(x,y)
    }

    # lato obliquo sinistro
    x1 <- c(1:9)/10;x3 <- rep(0,9);x2 <- 1-(x1+x3)
    P <- cbind(x1,x2,x3)
    for (i in 1:nrow(P)) {
        z <- P[i,]
        xx <- sum(xtra*z)
        yy <- sum(ytra*z)
        x1 <- xx-eps
        x2 <- xx+eps
        x <- c(x1,x2)
        b <- tan(pi/3); b <- -0.7
        a <- yy - b*xx
        y <- a + b*x
        lines(x,y)
    }
}
