wilson.1prop <-
function(x,n,conf=0.95)
{
    z <- qnorm((1-conf)/2,lower.tail=FALSE)

    ph <- x/n

    aa <- 1 + z^2/n
    bb <- -(ph + z^2/(2*n))
    cc <- ph^2
    discr <- bb^2 - aa*cc
    l <- (-bb - sqrt(discr))/aa
    u <- (-bb + sqrt(discr))/aa
    c(l,u)
}
