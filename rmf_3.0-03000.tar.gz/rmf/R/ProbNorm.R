ProbNorm <-
function(da=NA,a=NA,mu=0,sigma=1,density=20,angle=45,color=NA)
{
     if ( (!is.na(da)) & (!is.na(a)) ) {
        if (da>a) {
           tmp <- da
           da <- a
           a <- tmp
        }
     }
     if (is.na(da)) pval1 <- 0 else pval1 <- pnorm(da,mean=mu,sd=sigma,lower.tail=TRUE)
     if (is.na( a)) pval2 <- 1 else pval2 <- pnorm( a,mean=mu,sd=sigma,lower.tail=TRUE)
     Normale(mu=mu, sigma=sigma)
     if (is.na(da)) xda <- mu - 3.5*sigma else xda <- da
     if (is.na( a))  xa <- mu + 3.5*sigma else  xa <-  a
     FillNorm(xda,xa,mu,sigma,density,angle,color)

     out1 <- "La probabilita' di osservare un valore"
     if ( (!is.na(da)) & (!is.na(a)) )
         out2 <- paste("\ncompreso fra",da,"e",a)
     if ( (is.na(da)) & (!is.na(a)) )
        out2 <- paste("\nminore di",a)
     if ( (!is.na(da)) & (is.na(a)) )
        out2 <- paste("\nmaggiore di",da)
     out3 <- paste("\ne' uguale a",(pval2-pval1))
     out <- paste(out1,out2,out3)
     cat(out,"\n")
}
