print.tc <-
function(x, ...)
{
    tbl <- x$tbl
    names(dimnames(tbl)) <- c(x$vRig,x$vCol)
    if (x$label) print(dimnames(tbl)[2])
    wrtTab(tbl)
    cq <- x$cq; glib <- x$glib
    r <- paste("CHI QUADRATO =",sprintf("%8.3f",cq$stat))
    r <- paste(r," (GRADI DI LIBERTA' =",sprintf("%3.0f",glib),")",sep="")
    cat("","\n")
    cat(r,"\n")
    r <- paste("p-value del test chi-quadrato =",sprintf("%6.3f",cq$p.val),sep="")
    if (!is.null(x$tef)) {
       r <- paste(r,"; p-value 'esatto' =",sprintf("%6.3f",x$tef$p.val),sep="")
    }
    cat(r,"\n")
    r <- paste("CELLE CON F.A. < 5 =",sprintf("%3.0f",x$nmin5),sep="")
    r <- paste(r," - CELLE CON F.A. < 1 =",sprintf("%3.0f",x$nmin1),sep="")
    cat(r,"\n")

    if (nrow(tbl)==2){
       nCol <- ncol(tbl)
       odr <- rep(1,nCol)
       for (i in 2:nCol)odr[i] <- tbl[1,i]*tbl[2,1]/(tbl[1,1]*tbl[2,i])
       r <- "Odds Ratio "
       for (i in 1:nCol)r <- paste(r,sprintf("%5.2f",odr[i]),"  ",sep="")
       cat("\n");cat(r,"\n")
       r <- "Reciproco  "
       for (i in 1:nCol)r <- paste(r,sprintf("%5.2f",1/odr[i]),"  ",sep="")
       cat(r,"\n")
}
}
