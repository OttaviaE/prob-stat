print.simIC <-
function(obj, ...) print(obj$out)
