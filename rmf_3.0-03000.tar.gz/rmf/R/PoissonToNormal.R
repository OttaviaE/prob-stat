PoissonToNormal <-
function(mu=1,da=0,a=20,dettaglio=FALSE,grafico=TRUE,...)
{
     x <- c(da:a)
     y <- dpois(x,mu)
     e <- mu
     v <- mu
     xn1 <- x - 0.5
     xn2 <- x + 0.5

     if (grafico) {
        plot(x,y,type="h",ylab="f(x)",main=paste("Distribuzione di Poisson: mu=",mu,sep=""),...)
        curve(dnorm(x,mean=e,sd=sqrt(v)),add=TRUE)
     }
     if (dettaglio) {
        Fn <- pnorm(xn2,e,sqrt(v))
        yn <- c(Fn[1],diff(Fn))
        yy <- cumsum(dpois(c(0:a),mu))
        if (da>0) yy <- yy[-c(0:da)] # lo zero � al posto uno
        if (da>0) yn[1] <- pnorm((da+0.5),e,sqrt(v))-pnorm((da-0.5),e,sqrt(v))
        out <- cbind(x,y,yn,yy,Fn)
        colnames(out) <- c("x","f(x)","n(x)","F(x)","N(x)")
        tit <- paste("Distribuzione di Poisson (da",da,"a",a,") approssimata con una Normale")
        titolo(tit)
        cat("mu:",mu,"\n")
        stampa(e,v,y)
        print(out)
     }
}
