marascuilo <-
function(tbl)
{
    d <- dim(tbl)
    if (length(d) != 2) stop ("L'argomento non e' corretto.")
    if (d[1] != 2) stop ("La tabella deve avere due righe.")
    if (d[2] <  3) stop ("La tabella deve avere almeno tre colonne.")

    num <- tbl[1,]
    den <- colSums(tbl)
    p <- num/den

    delta <- outer(p,p,"-")
    k <- ncol(tbl)
    varp <- p*(1-p)/den
    vard <- outer(varp,varp,"+")

    test <- delta^2/vard
    pval <- pchisq(test,(k-1),lower.tail=FALSE)

    diag(delta) <- NA
    diag(test)  <- NA
    diag(pval)  <- NA

    out <- list(tbl=tbl,delta=delta,varDif=vard,
                statistics=test,p.value=pval)
    class(out) <- "marascuilo"
    return(out)
}
