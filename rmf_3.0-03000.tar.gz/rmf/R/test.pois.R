test.pois <-
function(x,n=1,lambda0=NA,conf=0.95)
{
    umalpha <- conf
    if (umalpha > 1) umalpha <- umalpha/100
    pr <- umalpha+(1-umalpha)/2
    zcr <- qnorm(pr)
    m1 <- x/n
    ds1 <- sqrt(m1)
    n1 <- n
    v1 <- ds1^2
    se <- sqrt(v1/n1)
    ei <- m1 - zcr*se
    es <- m1 + zcr*se
    xxx <- pois.exact(x,n,conf.level=umalpha)
    cat("media =",m1," es =",se," n =",n1,"\n")
    cat("I. C. approssimato al ",umalpha*100,
        "% per la media: da ",ei," a ",es,"\n",sep="")
    cat("I. C. esatto       al ",umalpha*100,
        "% per la media: da ",xxx$lower," a ",xxx$upper,"\n",sep="")

    if (!missing(lambda0)) {
       lambda <- lambda0
       v1 <- lambda
       se <- sqrt(v1/n1)
       z <- (m1 - lambda)/se
       pvalz <- pnorm(abs(z))
       pvalz <- (1 - pvalz)*2
       llambda <- lambda*n
       if (x<llambda) pval <- sum(dpois(0:x,llambda)) else pval <- 1-sum(dpois(0:x-1,llambda))
       pval <- 2*pval
       if (pval>1) pval <- 1
       cat("\nIpotesi nulla: lambda =",lambda," ES sotto H0 =",se,"\n")
       cat("Test z approssimato: ",z,
           "; p-value = ",pvalz,"\n",sep="")
       cat("Test esatto per una Poisson: p-value =",pval,"\n")
    }
}
