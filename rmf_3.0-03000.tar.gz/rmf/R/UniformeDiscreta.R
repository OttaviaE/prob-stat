UniformeDiscreta <-
function(da=0,a=9,dettaglio=TRUE,grafico=TRUE,...)
{
          x <- c(da:a)
          n <- a-da+1
          p <- 1/n
          y <- rep(p,n)
          e <- sum(x*y)
          v <- sum((x-e)^2*y)
          titolo("Distribuzione Uniforme Discreta")
          cat("da",da," a",a,"\n")
          stampa(e,v,y)
          if (grafico) {
             tit <- paste("Distribuzione Uniforme Discreta (da",da,"a",a,")")
             plot(x,y,type="h",ylab="f(x)",main=tit,...)
          } 
          if (dettaglio) {  
             out <- cbind(x,y,cumsum(y))
             colnames(out) <- c("x","f(x)","F(x)")
             print(out)
          }   
}
