summary.orci.pd <-
function(obj, ...)
{
    ll <- obj[1]
    ul <- obj[2]
    b  <- obj[3]
    c  <- obj[4]

    conf <- obj[5]

    cat("Intervallo di confidenza per l'odds ratio\nin due campioni dipendenti\n")
    cat("\nLivello di confidenza:",conf)
    cat("\nCoppie discordanti (b,c)",b,c)
    cat("\nOdds Ratio",c/b)
    cat("\nIntervallo di confidenza: da",ll,"a",ul,"\n")
}
