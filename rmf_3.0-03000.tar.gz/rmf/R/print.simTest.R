print.simTest <-
function(obj, ...) print(obj$xx)
