or_ci.pd <-
function(b,c,conf=0.95)
{
  z  <- qchisq(conf,1)
  A <- b + c + z
  B <- 2*c + z
  C <- c^2/(b+c)
  l <- (B - sqrt(B^2-4*A*C))/(2*A)
  u <- (B + sqrt(B^2-4*A*C))/(2*A)
  ll <- l/(1-l)
  ul <- u/(1-u)
  out <- c(ll,ul,b,c,conf)
  class(out) <- "orci.pd"
  return(out)
}
