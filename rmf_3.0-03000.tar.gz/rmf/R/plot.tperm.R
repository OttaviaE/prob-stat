plot.tperm <-
function(x, colore="black", tipo=19, ...)
{
    n <- length(x)
    y <- abs(x[n])
    att <- attributes(x)$Method
    hist(x,...)
    box()
    points(x[n],0,col=colore,pch=tipo)
    if (att == "Test di permutazione per dati appaiati") yy <- c(-y,y)
    if (att == "Test di permutazione per k campioni dipendenti") yy <- x[n]
    abline(v=yy,lty=3,lwd=2)
}
