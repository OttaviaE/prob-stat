mediana <-
function(x) {
   d <- x[!is.na(x)]
   d <- sort(d)
   n <- length(d)
   m <- n %%  2 # resto della divisione per 2
   k <- n %/% 2
   if (m==1) mdn <- d[k+1]              # n dispari
   if (m==0) mdn <- (d[n/2]+d[n/2+1])/2 # n pari
   dm <- length(x)-length(d)
   if (dm>0) cat("Osservazioni mancanti:",dm,"\n")
   mdn
}
