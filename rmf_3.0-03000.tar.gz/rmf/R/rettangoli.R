rettangoli <-
function(x,perc=TRUE,nome=NULL,...)
{
                if (is.null(nome)) nome <- substitute(x)
                nome <- as.character(nome)
                if (length(nome)>1) nome <- nome[length(nome)]
                d <- table(x)
                Ylab="Frequenze assolute"
                if (perc) {
                   d <- d/sum(d)*100
                   Ylab="Percentuale"
                }
                tit <- paste("Grafico a barre:",nome)
                barplot(d,ylab=Ylab,xlab=nome,main=tit,...)
}
