triplot.ese <-
function(griglia=TRUE,centro=TRUE)
{
h <- sqrt(3)/2
X <- matrix(nrow=121,ncol=3)
k <- 0
for (i in 0:10) {
    for (j in 0:10) {
         k <- k+1
         X[k,1] <- i/10
         X[k,2] <- j/10
         X[k,3] <- 1-(X[k,1]+X[k,2])
         if (X[k,3]<0) X[k,3] <- NA
    }
}
ok <- which(complete.cases(X))
X <- X[ok,]
triplot(X,cex.vert=2)
thicks()
if (griglia) griglia()
if (centro) centro()
}
