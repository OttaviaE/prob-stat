stampa <-
function(e,v,y) {
            cat("Valore atteso (media)   :",e,"\n")
            cat("Varianza                :",v,"\n")
            cat("Somma delle probabilita':",sum(y),"\n")
}
