G2 <-
function(tbl)
{
    cq <- chisq.test(tbl)
    O <- cq$obs
    A <- cq$exp
    out <- 2*sum(O*log(O/A))
    return(out)
}
