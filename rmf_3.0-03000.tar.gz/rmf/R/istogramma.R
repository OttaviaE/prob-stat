istogramma <-
function(x,da=NA,a=NA,nclassi=0,grafico=TRUE,
                       stampa=TRUE,destra=TRUE,nome=NULL,main=NULL)
{
    if (is.null(nome)) nome <- substitute(x)
    xlbl <- as.character(nome)
    if (length(xlbl)>1) xlbl <- xlbl[length(xlbl)]

    if (nclassi==0) {
       tmp <- hist(x,plot=FALSE,right=destra)
       tmp$intensities <- tmp$counts/sum(tmp$counts)
    }
    if (nclassi!=0) {
       if (is.na(da)) da <- min(x,na.rm=TRUE)
       if (is.na( a))  a <- max(x,na.rm=TRUE)
       tmp <- PrepHist(x,da,a,nclassi,destra)
    }
    nobs <- sum(complete.cases(x))
    nist <- sum(tmp$counts)
    if (nobs!=nist) cat("Non sono state incluse",(nobs-nist),"osservazioni.\n")
    if (grafico) PlotHist(tmp,xlbl,main)
    if (stampa)  PrintHist(tmp,destra)
}
