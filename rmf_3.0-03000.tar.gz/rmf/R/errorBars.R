errorBars <-
function(ymn,ysd,xlb,ymx=NULL,...)
{
    if(is.null(ymx)) ymx <- max(ymn)+max(ysd)
    midp <- barplot(ymn,names=xlb,...)
    g <- (max(midp) - min(midp))/50
    for (i in 1:length(midp)) {
        lines(c(midp[i],midp[i]),c(ymn[i]+ysd[i],ymn[i]-ysd[i]))
        lines(c(midp[i]-g,midp[i]+g),c(ymn[i]+ysd[i], ymn[i]+ysd[i]))
        lines(c(midp[i]-g,midp[i]+g),c(ymn[i]-ysd[i], ymn[i]-ysd[i]))
}
}
