simexp <-
function(n=10,rate=1,nrep=10000,grafico=TRUE)
{
     nobs <- n
     nsim <- nrep
     xmean <- replicate(nsim,mean(rexp(nobs,rate)))
     xm <- mean(xmean)
     xv <- var(xmean)
     ds <- sqrt(xv)
     se <- ds/sqrt(nobs)
     mu <- 1/rate; sigma <- mu
     cat("Simulazione di ",nrep," campioni, ciascuno di dimensione ",n,",\n",sep="")
     cat("estratti da una esponenziale con media",mu,"e deviazione standard",sigma,"\n")
     cat("La media    delle medie e' ",xm,"\n")
     cat("La varianza delle medie e' ",xv,"\n")
     cat("La d.s.     delle medie e' ",sqrt(xv),"\n")
     if (nrep>=10000 & grafico) AddNorm(xmean,mu=mu,se=sigma/sqrt(n))
     xmean
}
