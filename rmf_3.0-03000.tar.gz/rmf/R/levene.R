levene <-
function(y,x)
{
    ok <- complete.cases(y,x)
    y <- y[ok]
    x <- x[ok]
    m <- tapply(y,x,median)
    xx <- as.numeric(x)
    res <- numeric(length(y))
    for (j in 1:length(xx)) {
        ok <- which(xx == j)
        res[ok] <- abs(y[ok] - m[j])
    }
    fit <- lm(res ~ as.factor(xx))
    out <- anova(fit)
    att <- attributes(out)
    att$heading[1]  <- "Analysis of Variance Table (Levene's test)"
    att$heading[2]  <- "Response: median absolute residuals"
    attributes(out) <- att
    return(out)
}
