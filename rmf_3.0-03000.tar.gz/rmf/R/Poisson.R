Poisson <-
function(mu=1, da=0, a=10, dettaglio=TRUE, grafico=TRUE,...)
{
     x <- c(da:a)
     y <- dpois(x,mu)
     e <- mu
     v <- mu
     titolo("Distribuzione di Poisson")
     cat("mu: ",mu,"\n")
     stampa(e,v,y)
     if (grafico) {
        tit <- paste("Distribuzione di Poisson: mu=",mu,sep="")
        plot(x,y,type="h",ylab="f(x)",main=tit,...)
     }
     if (dettaglio) {
        yy <- cumsum(dpois(c(0:a),mu))
        if (da>0) yy <- yy[-c(0:da)] # lo zero � al posto uno
        out <- cbind(x,y,yy)
        colnames(out) <- c("x","f(x)","F(x)")
        print(out)
     }
}
