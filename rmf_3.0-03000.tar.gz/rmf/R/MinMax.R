MinMax <-
function(x)
{
   d <- x[!is.na(x)]
   dmin <- min(d)
   dmax <- max(d)
   r <- dmax-dmin
   cat("Minimo:",dmin," Massimo:",dmax," Range:",r,"\n")
}
