confint.marascuilo <-
function (obj, parm, level = 0.95, ...)
{
    k <- ncol(obj$tbl)
    if (is.null(dimnames(tbl))) {
        rownames(tbl) <- c(1:2)
        colnames(tbl) <- c(1:k)
    }
    cnms <- colnames(tbl)
    kk <- k*(k-1)/2
    coefs <- matrix(NA,kk,3)
    colnames(coefs) <- c("Diff","Lower","Upper")
    rownames(coefs) <- c(1:kk)
    kk <- 0
    w <- sqrt(qchisq(level,(k-1)))
    for (i in 1:(k-1)) {
        for (j in ((i+1):k)) {
            kk <- kk+1
            d <- obj$delta[i,j]
            se <- sqrt(obj$varDif[i,j])
            me <- w*se
            coefs[kk,] <- c(d,d-me,d+me)
            rownames(coefs)[kk] <- paste(cnms[i],"-",cnms[j])
}}
    return(coefs)
}
