pivot <-
function(zzz,ndec=1)
{
    ok <- is.data.frame(zzz)
    if (!ok) stop("L'argomento non e' un data-frame.")

    nvar <- ncol(zzz)
    if (nvar<2) {
       frq(zzz)
       return(invisible(NULL))
    }

    out.a <- ftable(zzz)
    pcg.a <- prop.table(out.a,margin=1)*100

    n <- rep("",nrow(zzz)) # variabile dummy
    o <- c(nvar:1)
    zzz <- data.frame(zzz[,o],n)
    out.b <- ftable(zzz)
    out.c <- data.frame(out.b)

    # elimino la colonna "dummy" e torno all'ordine originale
    o <- c(nvar:1,ncol(out.c))
    out.d <- out.c[,o]

    # attacco la percentuale
    yyy <- matrix(1:nrow(out.d),ncol=ncol(pcg.a))
    yyy <- t(yyy)
    yyy <- as.vector(yyy)
    xxx <- as.vector(pcg.a)
    xxx <- xxx[yyy]
    xxx <- round(xxx,ndec)
    out.e <- data.frame(out.d,"Perc"=xxx)

    out.e
}
