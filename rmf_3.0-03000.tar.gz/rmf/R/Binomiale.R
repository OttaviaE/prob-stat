Binomiale <-
function(n=10,p=0.5,da=0,a=n,dettaglio=TRUE,grafico=TRUE,...)
{
     if (n<1)        n <- 10
     if (p<=0)       p <- 0.5
     if (p>=1)       p <- 0.5
     x <- c(da:a)
     y <- dbinom(x,n,p)
     e <- n*p
     v <- n*p*(1-p)
     titolo("Distribuzione Binomiale")
     cat("Numero delle prove      :",n,"\n")
     cat("Probabilita' di successo:",p,"\n")
     stampa(e,v,y)
     if (grafico) {
        tit <- paste("Distribuzione Binomiale: n=",n,", p=",p,sep="")
        plot(x,y,type="h",ylab="f(x)",main=tit,...)
     }
     if (dettaglio) {
        yy <- cumsum(dbinom(c(0:a),n,p))
        if (da>0) yy <- yy[-c(0:da)] # lo zero � al posto uno
        out <- cbind(x,y,yy)
        colnames(out) <- c("x","f(x)","F(x)")
        print(out)
     }
}
