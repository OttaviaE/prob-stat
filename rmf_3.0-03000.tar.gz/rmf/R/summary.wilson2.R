summary.wilson2 <-
function(obj, ...)
{
    a <- obj$dati[1]
    m <- obj$dati[2]
    b <- obj$dati[3]
    n <- obj$dati[4]
    cat("Intervallo di confidenza di Wilson per la\ndifferenza di due proporzioni indipendenti\n")
    cat("Livello di confidenza:",obj$conf)
    cat("\nPrimo   gruppo (successi, prove, p)",a,m,a/m)
    cat("\nSecondo gruppo (successi, prove, p)",b,n,b/n)
    cat("\nDifferenza fra le due proporzioni",a/m - b/n)
    cil <- obj$ic[2]; ciu <- obj$ic[3]
    cat("\nIntervallo di confidenza: da",cil,"a",ciu,"\n")
}
