spacedol <-
function(char=" ",k)
{
   if (length(char) != 1) stop ("Vettori non permessi.")
   if (length(k)    != 1) stop ("Vettori non permessi.")
   strdol <- ""
   for (i in 1:k) strdol <- paste(strdol,char,sep="")
   strdol
}
