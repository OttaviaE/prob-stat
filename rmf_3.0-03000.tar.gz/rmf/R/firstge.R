firstge <-
function(brk,x)
{
     first(brk,x)
}
