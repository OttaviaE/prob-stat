frq <-
function(X,cumul=FALSE,sort=FALSE,mult=100)
{
   abcd <- deparse(substitute(X))
   XX <- X
   X <- as.data.frame(X)
   cnms <- colnames(X)
   if (is.null(dim(XX))) cnms <- abcd
   ncl <- dim(X)[2]
   out <- vector("list",ncl)
   for (i in 1:ncl)
{
     x <- X[,i]
     f <- table(x)
     if (sort) f <- rev(sort(table(x)))
     t <- sum(f)
     pcg <- (f/t)*mult
     F <- cumsum(f)
     PCG <- (F/t)*mult
     xxx <- cbind(f,pcg)
     if(cumul) xxx <- cbind(f,F,pcg,PCG)
     attr(xxx,"missing") <- length(x)-t
     attr(xxx,"nome") <- cnms[i]
     out[[i]] <- xxx
}
     class(out) <- "frq"
     return(out)
}
