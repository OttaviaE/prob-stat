dimp <-
function(p, eps=NULL, conf=0.95)
{
    if (is.null(eps)) stop("Manca l'ampiezza dell'intervallo.")
    if (conf < 0.5 | conf >= 1) conf <- 0.95
    alfa <- 1-conf
    alfamez <- alfa/2
    z <- qnorm(alfamez,lower.tail=FALSE)
    ris <- (2*z)^2*p*(1-p)/eps^2
    resto <- ris%%10
    resto <- (resto != 0)*1
    out <- cbind(p,trunc(ris)+1)
    colnames(out) <- c("p","n")
    return(out)
}
