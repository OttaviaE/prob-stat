plotic <-
function(x,mu,uma,tit)
{
     n <- nrow(x)
     y <- c(1:n)
     plot(c(x[1,3],x[n,4]),c(y[1],y[n]),type="n",
          ylab="numero dell'intervallo",xlab="x",main=tit)
     abline(v=mu)
     x <- x[order(x[,6]),]
     for (i in 1:n) points(c(x[i,3],x[i,4]),c(y[i],y[i]),type="l")
}
