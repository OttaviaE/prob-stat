cutpoints <-
function(x,brk,destra=TRUE,estremo=TRUE)
{
    tmp <- cut(x,brk,right=destra,include.lowest=estremo)
    out <- ordered(tmp)
    out
}
