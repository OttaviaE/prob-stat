biIsto <-
function(x,y,...)
{
    z <- c(x,y)
    hh <- hist(z,plot=FALSE)
    hx <- hist(x,breaks=hh$breaks,plot=FALSE)
    hy <- hist(y,breaks=hh$breaks,plot=FALSE)
    pcgx <- hx$counts/sum(hx$counts)
    pcgy <- hy$counts/sum(hy$counts)

    amy <- max(pcgx,pcgy)
    amx <- max(hh$breaks)
    bmx <- min(hh$breaks)
    plot(c(0,0),c(0,0),xlim=c(bmx,amx),ylim=c(-amy,amy),type="n",...)

    nbr <- length(hh$breaks)-1
    for (i in 1:nbr) {
        x1 <- hh$breaks[i];   y1 <-  pcgx[i]
        x2 <- hh$breaks[i+1]; y2 <- -pcgy[i]
        DiRe(x1,x2,0,y1)
        DiRe(x1,x2,0,y2)
    }
}
