Missing <-
function(df)
{
    df <- as.data.frame(df)
    tmp <- apply(df,MARGIN=2,FUN=is.na)
    apply(tmp,MARGIN=2,FUN=sum)
}
