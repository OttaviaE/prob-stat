decili <-
function(x) quantile(x,probs = seq(0, 1, 0.10), na.rm = TRUE, type=1)
