summary.simIC <-
function(obj, ...)
{
     nrep <- obj$nrep
     conf <- obj$conf
     n <- obj$n
     mu <- obj$mu
     sigma <- obj$sigma
     out <- obj$out
     cih <- out[,4]
     cil <- out[,3]
     a <- out[,5]
     cat ("Simulazione di ",nrep," intervalli di confidenza al ",(conf*100),"%\n",sep="")
     cat ("su campioni di dimensione ",n," estratti da una normale\n",sep="")
     cat ("con media ",mu," e deviazione standard ",sigma,"\n",sep="")
     cat ("Numero di intervalli che cadono a sinistra di ",mu," :",(sum(cih<mu)),"\n")
     cat ("Numero di intervalli che cadono a destra   di ",mu," :",(sum(mu<cil)),"\n")
     cat ("Numero di intervalli che contengono il valore ",mu," :",(sum(a)),"\n")
     cat ("Percentuale di intervalli che contengono      ",mu," :",(sum(a)/nrep*100),"\n")
}
