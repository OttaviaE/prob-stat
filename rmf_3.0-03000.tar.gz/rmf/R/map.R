map <-
function (x, codx, factor=TRUE, order=NULL)
{
    if (!is.null(order)) factor <- TRUE
    y <- codx[x]
    f <- y
    if (factor &  is.null(order)) f <- factor (y, levels = sort(unique(codx)))
    if (factor & !is.null(order)) f <- ordered(y, levels=order)
    f
}
