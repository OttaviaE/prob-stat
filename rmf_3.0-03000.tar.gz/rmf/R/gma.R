gma <-
function(x)
{
    if (class(x) != "Date") stop("L'oggetto in input non e' di classe date")
    anno <- as.numeric(format(x,"%Y"))
    mese <- as.numeric(format(x,"%m"))
    gior <- as.numeric(format(x,"%d"))
    list(giorno=gior,mese=mese,anno=anno)
}
