t2dr <-
function(d,nrep=10000)
{
    x <- abs(d)
    n <- length(x)
    out <- numeric(nrep)
    for (i in 1:(nrep-1)) {
        sig <- sample(c(-1,1),n,replace=TRUE)
        y <- x*sig
        out[i] <- mean(y)/sqrt(var(y)/n)
    }
    out[nrep] <- mean(d)/sqrt(var(d)/n)
    attr(out,"Method") <- "Test di permutazione per dati appaiati"
    class(out) <- "tperm"
    out
}
