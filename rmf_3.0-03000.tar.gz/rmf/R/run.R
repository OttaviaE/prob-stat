run <-
function(x)
{
    l <- length(x)
    i <- 1
    nrun <- 1
    y <- x[1]
    repeat {
        i <- i+1
        if (i > l) break
        if (x[i] != y) {
           nrun <- nrun + 1
           y <- x[i]
        }
    }
    return(nrun)
}
