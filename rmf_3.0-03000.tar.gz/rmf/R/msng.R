msng <-
function(x,value) 
{
    x[x==value] <- NA
    x
}
