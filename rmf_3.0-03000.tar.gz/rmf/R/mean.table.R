mean.table <-
function(x, ...)
{
    if (class(x) != "table") stop("L'oggetto non e' una tabella.")
    if (length(dim(x))>1) stop("La tabella ha piu' di una dimensione.")
    xx <- as.numeric(names(x))
    yy <- sum(xx*x)
    return(yy/sum(x))
}
