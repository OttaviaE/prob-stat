aov.mr <-
function(Y,...)
{
    if (!is.matrix(Y)) Y <- as.matrix(Y)
    fit.a <- lm(Y ~ 1)
    fit.b <- update(fit.a, ~ 0)
    anova(fit.a, fit.b, X=~1, test="Spherical", ...)
}
