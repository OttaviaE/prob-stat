print.frq <-
function(x, ...)
{

     if(!is.list(x)) stop("L'argomento in input non e' una lista.")
     nlst <- length(x)
     for (i in 1:nlst)
{
         xx <- x[[i]]
         cumul <- FALSE
         if (ncol(xx) != 2) cumul <- TRUE
         nf <- rownames(xx)
         n <- nrow(xx)
         t <- sum(xx[,1])
         f <- xx[,1]
         f <- append(f,t)
         pcg <- xx[,2]
         if (cumul) pcg <- xx[,3]
         pcg <- append(pcg,sum(pcg))
         nf <- append(nf," ")
         FX <- cbind(format(nf),format(f),format(pcg))

         if (cumul) {
            F <- xx[,2]
            PCG <- xx[,4]
            F <- append(F,NA)
            PCG <- append(PCG,NA)
            FX <- cbind(format(names(f)),
                        format(f),
                        format(pcg),
                        format(F),
                        format(PCG))
     }

     nch <- nchar(FX[1,])+2
     r <- ""
     nii <- 3
     if (cumul) nii <- 5
     for (i in 1:nii) {
         r <- paste(r,"+",sep="")
         for (j in 1:nch[i]) r <- paste(r,"-",sep="")
     }
     riga <- paste(r,"+",sep="")

     abcd <- c("x ","n ","f ")
     if (cumul) abcd <- c("x ","n ","f ","N ","F ")

     r <- ""
     for (i in 1:nii) {
         r <- paste(r," ",sep="")
         for (j in 1:(nch[i]-2)) r <- paste(r," ",sep="")
         r <- paste(r,abcd[i],sep="")
     }
     intesta <- r

     cat(attributes(xx)$nome,"\n")
     cat(intesta,"\n")
     cat(riga,"\n")
     for (i in 1:n) {
         r <- paste("|",FX[i,1],"|",FX[i,2],"|",FX[i,3],"|")
         if (cumul) r <- paste("|",FX[i,1],"|",FX[i,2],"|",FX[i,3],"|",FX[i,4],"|",FX[i,5],"|")
         cat(r,"\n")
     }
     cat(riga,"\n")
     if (!cumul) {
        r <- paste(" ",FX[n+1,1]," ",FX[n+1,2]," ",FX[n+1,3]," ")
        cat(r,"\n")
     }
     cat("Osservazioni mancanti:",
         attributes(xx)$missing,"\n\n")
}
}
