simunif <-
function(n=10,da=0,a=9,nrep=10000,grafico=TRUE)
{
     nobs <- n
     nsim <- nrep
     pop <- c(da:a)
     prob <- rep(1/length(pop),length(pop))
     xmean <- replicate(nsim,mean(sample(pop,nobs,replace=TRUE,prob=prob)))
     xm <- mean(xmean)
     xv <- var(xmean)
     ds <- sqrt(xv)
     cat("Simulazione di ",nrep," campioni, ciascuno di dimensione ",n,",\n",sep="")
     cat("estratti da una distribuzione uniforme discreta fra",da,"e",a,"\n")
     cat("La media    delle medie e' ",xm,"\n")
     cat("La varianza delle medie e' ",xv,"\n")
     cat("L'ES        delle medie e' ",sqrt(xv),"\n")
     if (nrep>=10000 & grafico) AddNorm(xmean,mu=4.5,se=sqrt(8.25/n))
     xmean
}
