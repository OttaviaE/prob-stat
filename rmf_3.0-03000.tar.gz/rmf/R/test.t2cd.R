test.t2cd <-
function(dati,conf=0.95)
{
    dimd <- dim(dati)
    if (is.null(dimd)) {
       stop ("I dati di input devono essere sotto forma di due colonne.") 
    }
    if (dimd[2]<2) {
       stop ("I dati di input devono essere sotto forma di due colonne.") 
    }

    umalpha <- conf
    if ((umalpha <0.4) | (umalpha>=1)) umalpha <- 0.95
    pr <- umalpha+(1-umalpha)/2

    x1 <- dati[,1]
    x2 <- dati[,2]
    delta <- (x1 - x2)
    d1 <- x1[!is.na(x1)]
    d2 <- x2[!is.na(x2)]
    m1 <- mean(d1)
    m2 <- mean(d2)
    m.delta <- mean(delta,na.rm=TRUE)
    v1 <- var(d1)
    v2 <- var(d2)
    v.delta <- var(delta,na.rm=TRUE)
    n1 <- length(d1)
    n2 <- length(d2)
    n.delta <- sum(!is.na(delta))

    grl <- n.delta - 1
    se <- sqrt(v.delta/n.delta)
    tt <- abs(m.delta)/se
    p <- 2*pt(tt,grl,lower.tail=FALSE)
    tcr <- qt(pr,grl)
    ei <- m.delta - tcr*se
    es <- m.delta + tcr*se
    cat("Primo   campione: media =",m1," d.s. =",sqrt(v1)," n =",n1,"\n")
    cat("Secondo campione: media =",m2," d.s. =",sqrt(v2)," n =",n2,"\n")
    cat("Differenze      : media =",m.delta,
        " d.s. =",sqrt(v.delta)," n =",n.delta,"\n")

    cat("\nTest t =",tt," g.l. =",grl," p-value =",p,"\n")
    cat("t critico = ",tcr,"  I.C. al ",umalpha*100,
        "% per la differenza: da ",ei," a ",es,"\n",sep="")
}
