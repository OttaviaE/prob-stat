griglia <-
function(lty=3)
{
    h <- sqrt(3)/2
    xtra <- c(0.5,0,1); ytra <- c(h,0,0)

    # base
    x1 <- rep(0,9);x2 <- c(1:9)/10;x3 <- 1-(x1+x2)
    P <- cbind(x1,x2,x3)
    base <- matrix(nrow=9,ncol=2)
    for (i in 1:nrow(P)) {
        z <- P[i,]
        xx <- sum(xtra*z)
        yy <- sum(ytra*z)
        base[i,1] <- xx
        base[i,2] <- yy
    }

    # lato obliquo destro
    x1 <- c(1:9)/10;x2 <- rep(0,9);x3 <- 1-(x1+x2)
    P <- cbind(x1,x2,x3)
    lobd <- matrix(nrow=9,ncol=2)
    for (i in 1:nrow(P)) {
        z <- P[i,]
        xx <- sum(xtra*z)
        yy <- sum(ytra*z)
        lobd[i,1] <- xx
        lobd[i,2] <- yy
    }

    # lato obliquo sinistro
    x1 <- c(1:9)/10;x3 <- rep(0,9);x2 <- 1-(x1+x3)
    P <- cbind(x1,x2,x3)
    lobs <- matrix(nrow=9,ncol=2)
    for (i in 1:nrow(P)) {
        z <- P[i,]
        xx <- sum(xtra*z)
        yy <- sum(ytra*z)
        lobs[i,1] <- xx
        lobs[i,2] <- yy
    }

    xxx <- cbind(lobs[,1],lobd[,1])
    yyy <- cbind(lobs[,2],lobd[,2])
    for (i in 1:9) lines(xxx[i,],yyy[i,],lty=lty)

    xxx <- cbind(lobs[,1],rev(base[,1]))
    yyy <- cbind(lobs[,2],base[,2])
    for (i in 1:9) lines(xxx[i,],yyy[i,],lty=lty)

    xxx <- cbind(lobd[,1],base[,1])
    yyy <- cbind(lobd[,2],base[,2])
    for (i in 1:9) lines(xxx[i,],yyy[i,],lty=lty)
}
