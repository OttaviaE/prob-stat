summary.simTest <-
function(obj, ...)
{
     alpha <- obj$alpha
     mu0 <- obj$mu0
     mu1 <- obj$mu1
     zcrit <- obj$zcrit
     n <- obj$n
     sem <- obj$sem
     za2 <- obj$za2
     df <- obj$xx
     nrep <- obj$nrep
     a <- obj$a
     z <- df$z
     cat ("Simulazione di",nrep,"campioni, ciascuno di dimensione",n,"\nper verificare l'ipotesi nulla mu =",mu0, "\nrispetto ad una alternativa bilaterale\n")
     cat ("ad un livello di significativita' alpha =",alpha,"\n")
     if (is.null(mu1))  cat("quando l'ipotesi nulla e' vera.\n")
     if (!is.null(mu1)) cat("quando l'ipotesi nulla e' falsa e la media vera e'",mu1,"\n")
     cat ("La deviazione standard della popolazione e'",sem*sqrt(n),"\ne l'errore standard e'",sem,"\n")
     cat ("Regione di rifiuto: medie inferiori a",(mu0-zcrit*sem)," o superiori a",(mu0+zcrit*sem),"\n")
     cat ("Numero di test non significativi :           ",nrep-(sum(a)),"\n")
     cat ("Numero di test significativi (coda sinistra):",(sum(z<(-za2))),"\n")
     cat ("Numero di test significativi (coda destra):  ",(sum(z>za2)),"\n")
     cat ("Percentuale di test significativi:           ",(sum(a)/nrep*100),"\n")
}
