xybar <-
function(x,y,plot=TRUE,out=FALSE,digits=1,test=TRUE,...)
{
    tbl <- table(y,x)
    ptb <- prop.table(tbl,margin=2)
    yy <- table(y)
    if (plot) {
        barplot(ptb,beside=TRUE,legend.text=names(yy),...)
        box()
     }
    if (out) print(round(ptb*100,digits))
    if (test) print(chisq.test(tbl))
}
